/**
 * Central site configuration.
 *
 * Every piece of copy that appears in more than one place — or that the
 * client will want to edit later — should live here instead of being
 * hard-coded inside components.
 */
export const siteConfig = {
  name: "Nexora Growth",
  shortName: "Nexora",
  tagline: "Creative systems built to make attention convert.",
  description:
    "Nexora Growth is a digital marketing agency specializing in performance marketing, SEO, paid social, and conversion-focused creative for ambitious brands.",
  foundedYear: 2018,
  location: "Dhaka, Bangladesh",
  email: "hello@nexoragrowth.com",
  phone: "+880 1700-000000",
  whatsapp: "https://wa.me/8801700000000",
  addressLine: "Gulshan Avenue, Dhaka 1212, Bangladesh",
  social: {
    linkedin: "https://linkedin.com/company/nexoragrowth",
    instagram: "https://instagram.com/nexoragrowth",
    x: "https://x.com/nexoragrowth",
    facebook: "https://facebook.com/nexoragrowth",
  },
  nav: {
    primary: [
      { label: "Home", href: "/#home" },
      { label: "Services", href: "/#services" },
      { label: "Work", href: "/#work" },
      { label: "About", href: "/#about" },
      { label: "Process", href: "/#process" },
      { label: "Contact", href: "/#contact" },
    ],
    utility: [
      { label: "Pricing", href: "/#pricing" },
      { label: "Insights", href: "/#insights" },
      { label: "FAQ", href: "/#faq" },
      { label: "Client Portal", href: "/login" },
    ],
  },
  cta: {
    primary: "Start a Project",
    secondary: "Explore Our Work",
    talkToExpert: "Talk to an Expert",
    buildPlan: "Build My Growth Plan",
  },
  portalLabel: "Secure Team & Client Workspace",
} as const;

export const heroMetrics = [
  { value: 120, suffix: "+", label: "Projects delivered" },
  { value: 48, suffix: "+", label: "Brands partnered" },
  { value: 3.7, suffix: "x", label: "Avg. campaign ROAS (benchmark)" },
  { value: 92, suffix: "%", label: "Client retention rate" },
] as const;

export const trustedByBrands = [
  "LUMA",
  "NOVA",
  "URBANKEY",
  "CLINIQ",
  "VERTEX",
  "BLOOM",
] as const;

export const performanceMetrics = [
  { value: 310, suffix: "+", label: "Campaigns managed" },
  { value: 2.4, suffix: "M", label: "Leads generated (cumulative)" },
  { value: 92, suffix: "%", label: "Average client retention" },
  { value: 14, suffix: "", label: "Markets served" },
  { value: 1800, suffix: "+", label: "Creative assets produced" },
] as const;

export const marketingStack = [
  "Google Ads",
  "Meta Ads",
  "GA4",
  "Search Console",
  "Looker Studio",
  "HubSpot",
  "Mailchimp",
  "Shopify",
  "WordPress",
  "Canva",
  "Figma",
] as const;
