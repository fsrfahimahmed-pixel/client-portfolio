import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Preloader from "@/components/Preloader";
import Hero from "@/components/sections/Hero";
import TrustedBy from "@/components/sections/TrustedBy";
import Services from "@/components/sections/Services";
import About from "@/components/sections/About";
import WhyUs from "@/components/sections/WhyUs";
import Industries from "@/components/sections/Industries";
import Process from "@/components/sections/Process";
import Work from "@/components/sections/Work";
import CaseStudy from "@/components/sections/CaseStudy";
import Metrics from "@/components/sections/Metrics";
import Team from "@/components/sections/Team";
import Testimonials from "@/components/sections/Testimonials";
import Pricing from "@/components/sections/Pricing";
import MarketingStack from "@/components/sections/MarketingStack";
import Insights from "@/components/sections/Insights";
import FAQ from "@/components/sections/FAQ";
import Contact from "@/components/sections/Contact";
import Newsletter from "@/components/sections/Newsletter";
import FinalCTA from "@/components/sections/FinalCTA";

export default function HomePage() {
  return (
    <>
      <Preloader />
      <Navbar />
      <main>
        <Hero />
        <TrustedBy />
        <Services />
        <About />
        <WhyUs />
        <Industries />
        <Process />
        <Work />
        <CaseStudy />
        <Metrics />
        <Team />
        <Testimonials />
        <Pricing />
        <MarketingStack />
        <Insights />
        <FAQ />
        <Contact />
        <Newsletter />
        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
