import type { Metadata } from "next";
import LegalPage from "@/components/legal/LegalPage";

export const metadata: Metadata = { title: "Privacy Policy" };

export default function PrivacyPolicyPage() {
  return (
    <LegalPage title="Privacy Policy" updated="Last updated: January 2026">
      <p>
        Nexora Growth collects only the information needed to respond to project inquiries and
        operate this website: contact details submitted through our forms, and standard analytics
        data about how the site is used.
      </p>
      <p>
        Information submitted through the project inquiry form is used solely to evaluate and
        respond to your request. We do not sell visitor data to third parties.
      </p>
      <p>
        This page is a prototype placeholder for the agency&apos;s public website. A complete
        privacy policy, aligned with applicable data protection regulations, will be published
        before production launch.
      </p>
    </LegalPage>
  );
}
