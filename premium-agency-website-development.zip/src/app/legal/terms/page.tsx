import type { Metadata } from "next";
import LegalPage from "@/components/legal/LegalPage";

export const metadata: Metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return (
    <LegalPage title="Terms of Service" updated="Last updated: January 2026">
      <p>
        These terms govern the use of the Nexora Growth public website. By browsing this site or
        submitting a project inquiry, you agree to interact with our content and forms in good
        faith and for legitimate business purposes.
      </p>
      <p>
        All case study metrics, client names, and figures shown on this website are demo content
        created for prototype purposes and should not be treated as audited claims or guarantees
        of future results.
      </p>
      <p>
        A complete terms of service document will be published once commercial engagements are
        formalized through signed service agreements.
      </p>
    </LegalPage>
  );
}
