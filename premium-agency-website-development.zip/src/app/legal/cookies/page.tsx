import type { Metadata } from "next";
import LegalPage from "@/components/legal/LegalPage";

export const metadata: Metadata = { title: "Cookie Policy" };

export default function CookiePolicyPage() {
  return (
    <LegalPage title="Cookie Policy" updated="Last updated: January 2026">
      <p>
        This website may use a minimal set of cookies and local storage entries to remember
        interface preferences and to let the project inquiry form work correctly.
      </p>
      <p>
        We do not currently use third-party advertising or tracking cookies. If analytics or
        marketing cookies are introduced in the future, this page will be updated with full
        disclosure and consent controls.
      </p>
    </LegalPage>
  );
}
