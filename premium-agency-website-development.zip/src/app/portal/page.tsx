import type { Metadata } from "next";
import Link from "next/link";
import { ShieldCheck } from "lucide-react";
import PortalShell from "@/components/portal/PortalShell";
import GlassCard from "@/components/ui/GlassCard";
import { buttonClasses } from "@/components/ui/buttonStyles";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = { title: "Portal" };

export default function PortalIndexPage() {
  return (
    <PortalShell>
      <div className="container-nexora flex flex-1 items-center justify-center py-16">
        <GlassCard level={3} className="w-full max-w-lg p-8 text-center sm:p-12">
          <div className="mx-auto flex items-center justify-center gap-2 text-xs font-medium text-accent">
            <ShieldCheck className="h-4 w-4" />
            {siteConfig.portalLabel}
          </div>
          <h1 className="mt-4 text-3xl font-semibold tracking-tight text-ink">
            Portal is being prepared.
          </h1>
          <p className="mt-4 text-sm leading-relaxed text-ink-muted">
            Role-based authentication and dashboards for Founders, Managers, and Employees arrive
            in the next build phase. Use the login screen to preview the planned structure.
          </p>
          <Link href="/login" className={buttonClasses("primary", "md", "mt-8")}>
            Go to login preview
          </Link>
        </GlassCard>
      </div>
    </PortalShell>
  );
}
