import type { Metadata } from "next";
import PortalShell from "@/components/portal/PortalShell";
import PortalPlaceholder from "@/components/portal/PortalPlaceholder";

export const metadata: Metadata = { title: "Employee Portal" };

export default function EmployeePortalPage() {
  return (
    <PortalShell>
      <PortalPlaceholder
        role="Employee"
        description="The Employee workspace will give each specialist a focused view of their own projects, tasks, and deadlines."
        capabilities={[
          "My projects",
          "My tasks",
          "Deadlines",
          "Project updates",
          "Files",
          "Comments",
          "Notifications",
          "Personal overview",
        ]}
      />
    </PortalShell>
  );
}
