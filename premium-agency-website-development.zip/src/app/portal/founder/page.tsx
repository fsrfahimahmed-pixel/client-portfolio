import type { Metadata } from "next";
import PortalShell from "@/components/portal/PortalShell";
import PortalPlaceholder from "@/components/portal/PortalPlaceholder";

export const metadata: Metadata = { title: "Founder Portal" };

export default function FounderPortalPage() {
  return (
    <PortalShell>
      <PortalPlaceholder
        role="Founder"
        description="The Founder workspace will give full visibility into every client, project, department, and team member across the agency."
        capabilities={[
          "Dashboard overview",
          "Employees & managers",
          "Departments",
          "Clients & all projects",
          "Project transfer & assignment",
          "Task management",
          "Reports & analytics",
          "Notifications & activity logs",
        ]}
      />
    </PortalShell>
  );
}
