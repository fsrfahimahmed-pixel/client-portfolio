import type { Metadata } from "next";
import PortalShell from "@/components/portal/PortalShell";
import PortalPlaceholder from "@/components/portal/PortalPlaceholder";

export const metadata: Metadata = { title: "Manager Portal" };

export default function ManagerPortalPage() {
  return (
    <PortalShell>
      <PortalPlaceholder
        role="Manager"
        description="The Manager workspace will coordinate department teams, assign work, and track delivery against client expectations."
        capabilities={[
          "Assigned projects",
          "Department team",
          "Assign employees",
          "Project progress",
          "Task management",
          "Deadlines",
          "Client communication",
          "Team performance",
        ]}
      />
    </PortalShell>
  );
}
