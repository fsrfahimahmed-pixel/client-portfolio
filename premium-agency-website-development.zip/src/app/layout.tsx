import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Manrope } from "next/font/google";
import "./globals.css";
import { siteConfig } from "@/config/site";
import { ToastProvider } from "@/components/ui/Toast";
import CustomCursor from "@/components/CustomCursor";
import ChatWidget from "@/components/chat/ChatWidget";

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://nexoragrowth.example"),
  title: {
    default: `${siteConfig.name} — Digital Marketing Agency`,
    template: `%s — ${siteConfig.name}`,
  },
  description: siteConfig.description,
  keywords: [
    "digital marketing agency",
    "performance marketing",
    "Google Ads agency",
    "Meta Ads agency",
    "SEO agency Bangladesh",
    "lead generation",
    "social media marketing",
    "marketing strategy",
  ],
  openGraph: {
    title: `${siteConfig.name} — Digital Marketing Agency`,
    description: siteConfig.description,
    siteName: siteConfig.name,
    type: "website",
  },
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={manrope.variable}>
      <body className="bg-bg text-ink antialiased selection:bg-accent selection:text-accent-ink">
        <ToastProvider>
          <div className="grain-overlay" aria-hidden="true" />
          <CustomCursor />
          {children}
          <ChatWidget />
        </ToastProvider>
      </body>
    </html>
  );
}
