import type { Metadata } from "next";
import Link from "next/link";
import { ShieldCheck, Lock, ArrowRight, Users2, Building2, UserCog } from "lucide-react";
import PortalShell from "@/components/portal/PortalShell";
import GlassCard from "@/components/ui/GlassCard";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = { title: "Login — Client & Team Portal" };

const roles = [
  {
    key: "founder",
    label: "Founder",
    icon: Building2,
    description: "Full visibility across clients, projects, and teams.",
  },
  {
    key: "manager",
    label: "Manager",
    icon: UserCog,
    description: "Department oversight and project assignment.",
  },
  {
    key: "employee",
    label: "Employee",
    icon: Users2,
    description: "Personal task and project workspace.",
  },
] as const;

export default function LoginPage() {
  return (
    <PortalShell>
      <div className="container-nexora flex flex-1 items-center justify-center py-16">
        <GlassCard level={3} className="w-full max-w-xl p-8 sm:p-12">
          <div className="flex items-center gap-2 text-xs font-medium text-accent">
            <ShieldCheck className="h-4 w-4" />
            {siteConfig.portalLabel}
          </div>
          <h1 className="mt-4 text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
            Secure Client &amp; Team Portal
          </h1>
          <p className="mt-4 text-sm leading-relaxed text-ink-muted">
            This is a development preview. Real authentication, role verification, and
            production dashboards arrive in the next build phase — nothing below is connected to
            a live account system.
          </p>

          <form className="mt-8 flex flex-col gap-4 opacity-70" aria-disabled="true">
            <label className="flex flex-col gap-2">
              <span className="text-xs font-medium text-ink-muted">Email</span>
              <input
                disabled
                placeholder="you@nexoragrowth.com"
                className="w-full rounded-xl border border-line bg-white/[0.03] px-4 py-3 text-sm text-ink-faint"
              />
            </label>
            <label className="flex flex-col gap-2">
              <span className="text-xs font-medium text-ink-muted">Password</span>
              <input
                disabled
                type="password"
                placeholder="••••••••••"
                className="w-full rounded-xl border border-line bg-white/[0.03] px-4 py-3 text-sm text-ink-faint"
              />
            </label>
            <button
              type="button"
              disabled
              className="mt-1 flex items-center justify-center gap-2 rounded-full border border-line bg-white/[0.03] px-6 py-3 text-sm font-semibold text-ink-faint"
            >
              <Lock className="h-4 w-4" /> Authentication not yet active
            </button>
          </form>

          <div className="mt-10 border-t border-line pt-8">
            <p className="label-micro mb-4 text-ink-faint">Development role preview</p>
            <div className="grid gap-3">
              {roles.map((role) => (
                <Link
                  key={role.key}
                  href={`/portal/${role.key}`}
                  className="group flex items-center justify-between rounded-xl border border-line bg-white/[0.02] px-4 py-3.5 transition-all duration-300 hover:border-accent/40 hover:bg-white/[0.05]"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/[0.05] text-ink-muted transition-colors group-hover:bg-accent/15 group-hover:text-accent">
                      <role.icon className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-ink">{role.label} preview</p>
                      <p className="text-xs text-ink-faint">{role.description}</p>
                    </div>
                  </div>
                  <ArrowRight className="h-4 w-4 text-ink-faint transition-transform duration-300 group-hover:translate-x-1 group-hover:text-accent" />
                </Link>
              ))}
            </div>
          </div>
        </GlassCard>
      </div>
    </PortalShell>
  );
}
