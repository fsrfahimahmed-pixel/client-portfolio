import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { buttonClasses } from "@/components/ui/buttonStyles";
import Reveal from "@/components/ui/Reveal";
import { projectsData } from "@/data/projects";
import { cn } from "@/lib/utils";

export function generateStaticParams() {
  return projectsData.map((project) => ({ slug: project.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const project = projectsData.find((p) => p.slug === slug);
  if (!project) return { title: "Case Study Not Found" };
  return {
    title: `${project.client} — ${project.service}`,
    description: project.summary,
  };
}

export default async function WorkDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const project = projectsData.find((p) => p.slug === slug);
  if (!project) notFound();

  const otherProjects = projectsData.filter((p) => p.slug !== project.slug).slice(0, 3);

  return (
    <>
      <Navbar />
      <main className="pt-28">
        <section className="container-nexora">
          <Link
            href="/#work"
            className="inline-flex items-center gap-1.5 text-sm text-ink-muted transition hover:text-ink"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Selected Work
          </Link>

          <Reveal direction="up" className="mt-8">
            <span className="label-micro text-accent">{project.industry}</span>
            <h1 className="mt-3 max-w-3xl text-balance text-[clamp(2rem,5vw,3.75rem)] font-semibold leading-[1.05] tracking-tight text-ink">
              {project.client} — {project.service}
            </h1>
            <p className="mt-5 max-w-2xl text-balance text-lg text-ink-muted">{project.summary}</p>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div
              className={cn(
                "mt-10 flex h-64 items-end rounded-card bg-gradient-to-br p-8 sm:h-80",
                project.gradient,
              )}
            >
              <span className="rounded-full bg-black/40 px-4 py-1.5 text-sm font-medium text-white backdrop-blur-sm">
                {project.projectType}
              </span>
            </div>
          </Reveal>
        </section>

        <section className="container-nexora mt-16 grid gap-12 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="flex flex-col gap-8">
            {[
              { label: "Challenge", text: project.caseStudy.challenge },
              { label: "Approach", text: project.caseStudy.approach },
            ].map((block) => (
              <Reveal direction="up" key={block.label}>
                <h2 className="text-xl font-semibold text-ink">{block.label}</h2>
                <p className="mt-3 text-base leading-relaxed text-ink-muted">{block.text}</p>
              </Reveal>
            ))}

            <Reveal direction="up">
              <h2 className="text-xl font-semibold text-ink">Execution</h2>
              <ul className="mt-3 space-y-2.5">
                {project.caseStudy.execution.map((item) => (
                  <li key={item} className="flex gap-2.5 text-base text-ink-muted">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                    {item}
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal direction="up">
              <div className="rounded-card border border-accent/30 bg-accent/5 p-6">
                <h2 className="text-lg font-semibold text-ink">Key takeaway</h2>
                <p className="mt-2 text-sm leading-relaxed text-ink-muted">
                  {project.caseStudy.takeaway}
                </p>
              </div>
            </Reveal>
          </div>

          <Reveal direction="left">
            <div className="rounded-card border border-line bg-white/[0.02] p-7">
              <h2 className="text-lg font-semibold text-ink">Results</h2>
              <div className="mt-5 grid grid-cols-2 gap-5">
                {project.metrics.map((metric) => (
                  <div key={metric.label}>
                    <p className="text-2xl font-semibold text-accent">{metric.value}</p>
                    <p className="mt-1 text-xs text-ink-faint">{metric.label}</p>
                  </div>
                ))}
              </div>
              <ul className="mt-6 space-y-2 border-t border-line pt-5 text-sm text-ink-muted">
                {project.caseStudy.results.map((result) => (
                  <li key={result}>{result}</li>
                ))}
              </ul>
              <Link href="/#contact" className={cn(buttonClasses("primary", "md", "mt-7 w-full"))}>
                Have a similar challenge? Start Your Project
                <ArrowUpRight className="h-4 w-4" />
              </Link>
            </div>
          </Reveal>
        </section>

        <section className="container-nexora mt-28">
          <h2 className="text-xl font-semibold text-ink">More selected work</h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-3">
            {otherProjects.map((p) => (
              <Link
                key={p.slug}
                href={`/work/${p.slug}`}
                className="group rounded-card border border-line bg-white/[0.02] p-5 transition-all duration-500 hover:-translate-y-1 hover:border-line-strong"
              >
                <div className={cn("h-28 rounded-xl bg-gradient-to-br", p.gradient)} />
                <p className="mt-4 text-sm font-semibold text-ink">{p.client}</p>
                <p className="text-xs text-ink-faint">{p.service}</p>
              </Link>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
