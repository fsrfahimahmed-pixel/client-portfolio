import type { LucideIcon } from "lucide-react";
import {
  Target,
  Search,
  Megaphone,
  LineChart,
  PenTool,
  MousePointerClick,
  Mail,
  Workflow,
  ShoppingCart,
  Sparkles,
  MapPin,
  BarChart3,
} from "lucide-react";

export interface ServiceItem {
  slug: string;
  name: string;
  shortDescription: string;
  benefit: string;
  deliverable: string;
  icon: LucideIcon;
  whyItMatters: string;
  deliverables: string[];
  outcome: string;
}

export const servicesData: ServiceItem[] = [
  {
    slug: "digital-strategy",
    name: "Digital Strategy",
    shortDescription: "A growth plan built around your real funnel, not a template.",
    benefit: "Clarity on where budget and creative effort should go first.",
    deliverable: "90-day growth roadmap",
    icon: Target,
    whyItMatters:
      "Most marketing underperforms because it skips strategy and jumps straight to execution. We map the funnel before we touch a single campaign.",
    deliverables: [
      "Audience & offer audit",
      "Channel prioritization",
      "90-day growth roadmap",
      "KPI and budget framework",
    ],
    outcome: "A clear, sequenced plan your team can execute with confidence.",
  },
  {
    slug: "performance-marketing",
    name: "Performance Marketing",
    shortDescription: "Paid acquisition engineered around cost-efficient growth.",
    benefit: "Predictable customer acquisition cost across channels.",
    deliverable: "Cross-channel media plan",
    icon: LineChart,
    whyItMatters:
      "Scaling spend without a measurement framework burns budget. We build full-funnel tracking before we scale anything.",
    deliverables: [
      "Cross-channel media planning",
      "Bid & budget optimization",
      "Conversion tracking setup",
      "Weekly performance reporting",
    ],
    outcome: "A media engine that scales spend only when the math works.",
  },
  {
    slug: "google-ads",
    name: "Google Ads",
    shortDescription: "Build campaigns around intent, not impressions.",
    benefit: "Capture demand at the exact moment someone is ready to buy.",
    deliverable: "Full-funnel search account build",
    icon: Search,
    whyItMatters:
      "Search is the highest-intent channel you have. Most accounts waste it on broad keywords and misaligned landing pages.",
    deliverables: [
      "Search campaigns",
      "Performance Max",
      "Conversion tracking",
      "Landing-page alignment",
      "Keyword strategy",
      "Creative testing",
    ],
    outcome: "Lower cost-per-lead with traffic that actually matches intent.",
  },
  {
    slug: "meta-ads",
    name: "Meta Ads",
    shortDescription: "Paid social built on creative testing, not guesswork.",
    benefit: "Scroll-stopping creative paired with precise audience design.",
    deliverable: "Always-on creative testing pipeline",
    icon: Megaphone,
    whyItMatters:
      "On Meta, creative is the targeting. We treat every ad as a hypothesis and let data decide the winner.",
    deliverables: [
      "Campaign strategy",
      "Audience design",
      "Creative testing framework",
      "Retargeting sequences",
      "Optimization & reporting",
    ],
    outcome: "Lower CPMs and higher thumb-stop rate as testing compounds.",
  },
  {
    slug: "seo",
    name: "SEO",
    shortDescription: "Technical, content, and authority work that compounds.",
    benefit: "Organic visibility that keeps paying you back after launch.",
    deliverable: "Technical audit + content roadmap",
    icon: Search,
    whyItMatters:
      "Paid traffic stops the moment you stop paying. SEO builds an asset that keeps generating pipeline.",
    deliverables: [
      "Technical SEO audit",
      "On-page optimization",
      "Content roadmap",
      "Link & authority building",
      "Local SEO where relevant",
    ],
    outcome: "Durable organic rankings for commercial, buyer-intent terms.",
  },
  {
    slug: "local-seo",
    name: "Local SEO",
    shortDescription: "Dominate the map pack for the neighborhoods that matter.",
    benefit: "More calls, directions, and walk-ins from nearby searches.",
    deliverable: "Google Business Profile optimization",
    icon: MapPin,
    whyItMatters:
      "For multi-location and local-service brands, map pack visibility often outperforms the main organic results.",
    deliverables: [
      "Google Business Profile optimization",
      "Local citation building",
      "Review & reputation strategy",
      "Location page structure",
    ],
    outcome: "Stronger local visibility across every active service area.",
  },
  {
    slug: "content-strategy",
    name: "Content Strategy",
    shortDescription: "Editorial systems that build trust before the sale.",
    benefit: "A content engine aligned to each stage of the funnel.",
    deliverable: "Quarterly content calendar",
    icon: PenTool,
    whyItMatters:
      "Content without a strategy becomes noise. We map topics to buyer questions and funnel stage.",
    deliverables: [
      "Audience research",
      "Content pillars & calendar",
      "SEO-aligned briefs",
      "Distribution plan",
    ],
    outcome: "Content that earns attention and moves people toward a decision.",
  },
  {
    slug: "conversion-optimization",
    name: "Conversion Rate Optimization",
    shortDescription: "Turn existing traffic into more qualified pipeline.",
    benefit: "More revenue without spending another dollar on traffic.",
    deliverable: "Landing-page testing roadmap",
    icon: MousePointerClick,
    whyItMatters:
      "Most sites leak conversions long before the traffic problem. We fix the leaks first.",
    deliverables: [
      "Funnel & heatmap analysis",
      "Landing-page testing roadmap",
      "Copy & UX recommendations",
      "A/B test execution",
    ],
    outcome: "Measurable lift in landing-page and checkout conversion rate.",
  },
  {
    slug: "email-marketing",
    name: "Email Marketing",
    shortDescription: "Lifecycle flows that turn leads into repeat customers.",
    benefit: "Owned-channel revenue that doesn't depend on ad platforms.",
    deliverable: "Lifecycle automation flows",
    icon: Mail,
    whyItMatters:
      "Email remains one of the highest-ROI channels when flows are mapped to real customer behavior.",
    deliverables: [
      "List segmentation",
      "Welcome & nurture flows",
      "Abandoned cart recovery",
      "Campaign calendar",
    ],
    outcome: "Higher repeat-purchase rate and stronger customer lifetime value.",
  },
  {
    slug: "marketing-automation",
    name: "Marketing Automation",
    shortDescription: "Systems that score, route, and nurture leads automatically.",
    benefit: "Faster follow-up and fewer leads falling through the cracks.",
    deliverable: "CRM + automation workflow map",
    icon: Workflow,
    whyItMatters:
      "Growth breaks when manual processes can't keep up with lead volume. Automation keeps response time fast.",
    deliverables: [
      "Lead scoring setup",
      "CRM workflow design",
      "Sales handoff automation",
      "Reporting dashboards",
    ],
    outcome: "A repeatable system that nurtures leads without manual effort.",
  },
  {
    slug: "ecommerce-growth",
    name: "E-commerce Growth",
    shortDescription: "Full-funnel systems built for online storefronts.",
    benefit: "Higher average order value and stronger repeat purchase rate.",
    deliverable: "Storefront growth audit",
    icon: ShoppingCart,
    whyItMatters:
      "E-commerce growth needs acquisition, retention, and merchandising working together, not in isolation.",
    deliverables: [
      "Storefront & catalog audit",
      "Paid acquisition strategy",
      "Retention & email flows",
      "Conversion optimization",
    ],
    outcome: "Compounding growth across acquisition, conversion, and retention.",
  },
  {
    slug: "brand-strategy",
    name: "Brand Strategy",
    shortDescription: "Positioning and identity that make marketing easier.",
    benefit: "A sharper story that every campaign can build on.",
    deliverable: "Brand positioning framework",
    icon: Sparkles,
    whyItMatters:
      "Performance marketing works harder when the brand story is distinct. Positioning is the multiplier.",
    deliverables: [
      "Market & competitor analysis",
      "Positioning framework",
      "Messaging guidelines",
      "Visual identity direction",
    ],
    outcome: "A consistent story that strengthens every channel it touches.",
  },
  {
    slug: "analytics-reporting",
    name: "Analytics & Reporting",
    shortDescription: "Reporting that tracks business outcomes, not vanity metrics.",
    benefit: "Clear visibility into what is actually driving revenue.",
    deliverable: "Executive performance dashboard",
    icon: BarChart3,
    whyItMatters:
      "Dashboards full of impressions and reach rarely explain whether marketing is working. We report on outcomes.",
    deliverables: [
      "Tracking & attribution setup",
      "Looker Studio dashboards",
      "Monthly performance review",
      "Forecasting models",
    ],
    outcome: "A single source of truth leadership can actually act on.",
  },
];
