export interface ProcessStep {
  number: string;
  title: string;
  description: string;
}

export const processData: ProcessStep[] = [
  {
    number: "01",
    title: "Discover",
    description:
      "We audit your funnel, audience, competitors, and past performance to understand what's actually happening.",
  },
  {
    number: "02",
    title: "Strategy",
    description:
      "We translate findings into a 90-day roadmap with clear channel priorities, KPIs, and budget framework.",
  },
  {
    number: "03",
    title: "Create",
    description:
      "Our creative team produces campaign assets, landing pages, and content aligned to the strategy.",
  },
  {
    number: "04",
    title: "Launch",
    description:
      "Campaigns go live with full tracking in place so every result is measurable from day one.",
  },
  {
    number: "05",
    title: "Optimize",
    description:
      "We run structured testing cycles — creative, audience, and landing page — to improve efficiency weekly.",
  },
  {
    number: "06",
    title: "Scale",
    description:
      "Once a channel proves efficient, we scale budget deliberately while protecting unit economics.",
  },
];
