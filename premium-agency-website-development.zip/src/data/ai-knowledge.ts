export interface AiQAPair {
  keywords: string[];
  question: string;
  answer: string;
}

/**
 * Local demo knowledge base for the on-site AI assistant.
 * Future: replace matchAiResponse with a real model API call behind a
 * server route, keeping this file as a fallback / seed data set.
 */
export const aiKnowledgeBase: AiQAPair[] = [
  {
    keywords: ["what do you do", "who are you", "about nexora", "what is nexora"],
    question: "What do you do?",
    answer:
      "We help growth-focused businesses acquire customers through performance marketing, SEO, social media, creative strategy, and conversion optimization.",
  },
  {
    keywords: ["services", "what services", "offer"],
    question: "What services do you offer?",
    answer:
      "Digital strategy, performance marketing, Google Ads, Meta Ads, SEO, local SEO, content strategy, conversion rate optimization, email marketing, marketing automation, e-commerce growth, brand strategy, and analytics & reporting.",
  },
  {
    keywords: ["meta ads", "facebook ads", "instagram ads"],
    question: "Do you run Meta Ads?",
    answer:
      "Yes. Our paid-social service includes campaign strategy, audience design, creative testing, optimization, and reporting — all managed in-house.",
  },
  {
    keywords: ["google ads", "search ads", "ppc"],
    question: "Do you run Google Ads?",
    answer:
      "Yes, including Search, Performance Max, and Shopping campaigns, with conversion tracking and landing-page alignment built in.",
  },
  {
    keywords: ["more leads", "need leads", "lead generation"],
    question: "I need more leads.",
    answer:
      "Start with our Lead Generation or Performance Marketing service. We'll evaluate your offer, traffic source, landing page, and conversion flow before recommending a channel.",
  },
  {
    keywords: ["ecommerce", "e-commerce", "online store", "shopify"],
    question: "How can you help an e-commerce brand?",
    answer:
      "We combine paid acquisition, conversion rate optimization, and retention email flows into one growth loop — see our Lumera case study for a real example.",
  },
  {
    keywords: ["different", "why you", "why choose", "better than"],
    question: "What makes your agency different?",
    answer:
      "We report on business outcomes, not vanity metrics, and every strategy starts with a funnel audit before a single ad goes live.",
  },
  {
    keywords: ["proposal", "quote", "pricing", "cost", "price"],
    question: "Can I request a proposal?",
    answer:
      "Yes — use the project form below or tell me a bit about your business and I can point you to the right starting package.",
  },
  {
    keywords: ["which service", "right for me", "recommend"],
    question: "Which service is right for me?",
    answer:
      "Tell me your industry and main goal (more traffic, more leads, more sales) and I can recommend the right starting service.",
  },
  {
    keywords: ["get started", "how do i start", "begin"],
    question: "How do I get started?",
    answer:
      "Tell us about your business through the project form and a specialist will review the opportunity within two business days.",
  },
  {
    keywords: ["seo", "search engine optimization", "ranking"],
    question: "Do you do SEO?",
    answer:
      "Yes — technical SEO, on-page optimization, content strategy, and local SEO for multi-location businesses.",
  },
  {
    keywords: ["result", "results", "how long", "timeline"],
    question: "How long before we see results?",
    answer:
      "Paid channels typically show early signal within 2–4 weeks. SEO and content compound over 3–6 months.",
  },
  {
    keywords: ["retainer", "monthly", "contract"],
    question: "Do you offer monthly retainers?",
    answer:
      "Yes — our Growth and Scale packages are monthly retainers with quarterly strategy reviews. Check the Pricing section for details.",
  },
  {
    keywords: ["team", "who works", "specialist"],
    question: "Who will work on my account?",
    answer:
      "A dedicated pod — typically a strategist, a performance specialist, and a creative lead — depending on the package you choose.",
  },
  {
    keywords: ["international", "outside bangladesh", "global"],
    question: "Do you work with international clients?",
    answer:
      "Yes, roughly half of our active clients are international brands across North America, the Middle East, and Southeast Asia.",
  },
  {
    keywords: ["hello", "hi", "hey"],
    question: "Hello",
    answer:
      "Hi! I'm Nova, Nexora Growth's AI assistant. Ask me about our services, past results, or how to get started.",
  },
];

const fallbackResponse =
  "That's a great question for one of our specialists. Try asking about our services, pricing, or results — or switch to the Human Agent tab to talk to the team directly.";

export function matchAiResponse(input: string): string {
  const normalized = input.toLowerCase();
  let best: { score: number; answer: string } | null = null;

  for (const entry of aiKnowledgeBase) {
    const score = entry.keywords.reduce(
      (acc, keyword) => (normalized.includes(keyword) ? acc + keyword.length : acc),
      0,
    );
    if (score > 0 && (!best || score > best.score)) {
      best = { score, answer: entry.answer };
    }
  }

  return best?.answer ?? fallbackResponse;
}

export const aiSuggestionChips = [
  "What services do you offer?",
  "Do you run Google Ads?",
  "I need more leads",
  "What makes you different?",
  "How do I get started?",
] as const;
