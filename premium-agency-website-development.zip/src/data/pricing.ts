export interface PricingTier {
  name: string;
  description: string;
  price: string;
  priceNote: string;
  highlighted: boolean;
  features: string[];
  cta: string;
}

export const pricingData: PricingTier[] = [
  {
    name: "Launch",
    description: "For businesses building a consistent marketing foundation.",
    price: "Starting from $1,200/mo",
    priceNote: "Best for a single primary channel",
    highlighted: false,
    features: [
      "Strategy & channel audit",
      "One primary acquisition channel",
      "Monthly reporting",
      "Email support",
    ],
    cta: "Build My Growth Plan",
  },
  {
    name: "Growth",
    description: "For businesses ready to scale acquisition across channels.",
    price: "Starting from $2,800/mo",
    priceNote: "Most selected engagement",
    highlighted: true,
    features: [
      "Full-funnel strategy",
      "Two to three acquisition channels",
      "Creative production included",
      "Bi-weekly reporting & reviews",
      "Dedicated account strategist",
    ],
    cta: "Build My Growth Plan",
  },
  {
    name: "Scale",
    description: "For brands running multi-channel growth systems.",
    price: "Custom Strategy",
    priceNote: "Tailored to scope & markets served",
    highlighted: false,
    features: [
      "Multi-channel growth system",
      "Dedicated pod of specialists",
      "Advanced automation & CRM integration",
      "Weekly reporting & live dashboard",
      "Quarterly strategy workshops",
    ],
    cta: "Talk to an Expert",
  },
];
