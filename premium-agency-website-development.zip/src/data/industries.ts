export interface Industry {
  name: string;
  description: string;
  example: string;
}

export const industriesData: Industry[] = [
  {
    name: "E-commerce",
    description: "Full-funnel acquisition and retention systems for online storefronts.",
    example: "Lumera grew repeat-purchase revenue 74% through lifecycle flows.",
  },
  {
    name: "Real Estate",
    description: "Lead qualification systems that save agents time and close more deals.",
    example: "UrbanKey increased qualified leads 210% with smarter intake.",
  },
  {
    name: "Healthcare",
    description: "Local SEO and booking funnels for multi-location providers.",
    example: "Cliniq Plus lifted booking submissions 156% across 9 locations.",
  },
  {
    name: "SaaS",
    description: "Demand generation built around qualified pipeline, not raw sign-ups.",
    example: "FutureLab grew sales-qualified demo requests by 88%.",
  },
  {
    name: "Professional Services",
    description: "Authority-driven positioning and organic growth for advisory brands.",
    example: "Vertex Finance grew organic consultation requests 64%.",
  },
  {
    name: "Education",
    description: "Enrollment funnels that nurture prospective students at every stage.",
    example: "Structured nurture sequences lifted application completion rates.",
  },
  {
    name: "Hospitality",
    description: "Demand campaigns tuned to seasonality and booking windows.",
    example: "Dynamic campaign pacing aligned with peak booking periods.",
  },
  {
    name: "Local Businesses",
    description: "Map-pack visibility and review systems that drive foot traffic.",
    example: "Local SEO systems built for multi-location service brands.",
  },
  {
    name: "Technology",
    description: "Positioning and content that make complex products easy to buy.",
    example: "Messaging frameworks that translate features into outcomes.",
  },
  {
    name: "Personal Brands",
    description: "Content systems that turn visibility into booked opportunities.",
    example: "Editorial content calendars built around audience trust.",
  },
];
