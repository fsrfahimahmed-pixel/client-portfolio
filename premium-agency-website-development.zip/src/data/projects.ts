export interface ProjectMetric {
  label: string;
  value: string;
}

export interface Project {
  slug: string;
  client: string;
  industry: string;
  service: string;
  category: "Performance" | "SEO" | "Social" | "E-commerce" | "Lead Generation" | "Brand Growth";
  projectType: string;
  summary: string;
  result: string;
  gradient: string;
  metrics: ProjectMetric[];
  caseStudy: {
    challenge: string;
    approach: string;
    execution: string[];
    results: string[];
    takeaway: string;
  };
}

export const projectsData: Project[] = [
  {
    slug: "lumaskin-growth-system",
    client: "LumaSkin",
    industry: "Beauty & E-commerce",
    service: "Meta Ads + Creative Strategy",
    category: "Social",
    projectType: "Paid social growth system",
    summary: "Rebuilt the paid-social engine around creative testing and retention flows.",
    result: "2.8x ROAS within one quarter",
    gradient: "from-[#caff5a] via-[#8fe36b] to-[#2b3a2d]",
    metrics: [
      { label: "ROAS", value: "2.8x" },
      { label: "CPL", value: "-31%" },
      { label: "CTR", value: "+54%" },
    ],
    caseStudy: {
      challenge:
        "LumaSkin had strong products but inconsistent paid-social performance and no structured creative testing.",
      approach:
        "We rebuilt audience architecture, introduced a weekly creative testing cadence, and layered in retention flows for repeat purchases.",
      execution: [
        "Rebuilt campaign structure around 3 core audience tiers",
        "Shipped 6 new creative concepts per week for testing",
        "Added post-purchase email and SMS retention flows",
        "Implemented server-side conversion tracking",
      ],
      results: [
        "+68% qualified leads",
        "-31% cost per lead",
        "2.8x ROAS",
        "+41% landing-page conversion",
      ],
      takeaway:
        "Creative testing velocity — not budget size — was the real lever behind LumaSkin's growth.",
    },
  },
  {
    slug: "urbankey-lead-engine",
    client: "UrbanKey",
    industry: "Real Estate",
    service: "Lead Generation",
    category: "Lead Generation",
    projectType: "Multi-channel lead engine",
    summary: "Built a qualified-lead pipeline across search, social, and landing pages.",
    result: "3.1x more qualified leads per month",
    gradient: "from-[#7c6cff] via-[#4b3fae] to-[#1a1830]",
    metrics: [
      { label: "Leads", value: "+210%" },
      { label: "CPL", value: "-24%" },
      { label: "Show-rate", value: "+37%" },
    ],
    caseStudy: {
      challenge:
        "UrbanKey generated leads, but most were unqualified and sales teams were wasting time on low-intent inquiries.",
      approach:
        "We rebuilt the qualification layer — smarter forms, intent-based landing pages, and lead scoring tied directly into the CRM.",
      execution: [
        "Rebuilt landing pages around property-type intent",
        "Added a 3-question qualification form",
        "Launched Google Search + Performance Max campaigns",
        "Introduced lead scoring and CRM routing",
      ],
      results: [
        "+210% qualified leads",
        "-24% cost per lead",
        "+37% appointment show-rate",
      ],
      takeaway:
        "Fixing qualification upstream mattered more than adding more top-of-funnel volume.",
    },
  },
  {
    slug: "lumera-ecommerce-growth",
    client: "Lumera",
    industry: "E-commerce — Home Goods",
    service: "E-commerce Growth",
    category: "E-commerce",
    projectType: "Full-funnel growth system",
    summary: "Combined acquisition, CRO, and retention into one growth loop.",
    result: "+74% repeat purchase revenue",
    gradient: "from-[#ffd166] via-[#e39a3a] to-[#2a1f12]",
    metrics: [
      { label: "AOV", value: "+22%" },
      { label: "Repeat rev.", value: "+74%" },
      { label: "CVR", value: "+1.8pp" },
    ],
    caseStudy: {
      challenge:
        "Lumera's acquisition was profitable but one-time; very few customers returned for a second purchase.",
      approach:
        "We layered retention mechanics — email flows, loyalty incentives, and bundle merchandising — onto the existing acquisition engine.",
      execution: [
        "Built post-purchase lifecycle email flows",
        "Introduced bundle and cross-sell merchandising",
        "Optimized checkout flow to reduce drop-off",
        "Added loyalty incentive for second purchase",
      ],
      results: ["+74% repeat purchase revenue", "+22% average order value", "+1.8pp checkout conversion"],
      takeaway:
        "Retention infrastructure turned paid acquisition into a compounding growth loop.",
    },
  },
  {
    slug: "cliniqplus-local-seo",
    client: "Cliniq Plus",
    industry: "Healthcare",
    service: "Local SEO + Lead Generation",
    category: "SEO",
    projectType: "Local visibility & booking growth",
    summary: "Rebuilt local search presence across 9 clinic locations.",
    result: "+156% booking form submissions",
    gradient: "from-[#4fd8e0] via-[#2a8f96] to-[#0f2527]",
    metrics: [
      { label: "Map views", value: "+183%" },
      { label: "Bookings", value: "+156%" },
      { label: "Rankings", value: "Top 3 in 9 areas" },
    ],
    caseStudy: {
      challenge:
        "Cliniq Plus had 9 clinic locations with inconsistent listings and almost no map-pack visibility.",
      approach:
        "We standardized every Google Business Profile, rebuilt location pages, and launched a structured review program.",
      execution: [
        "Standardized 9 Google Business Profiles",
        "Rebuilt location-specific landing pages",
        "Launched structured patient review program",
        "Fixed technical SEO issues across the site",
      ],
      results: ["+183% map-pack views", "+156% booking submissions", "Top 3 ranking in 9 service areas"],
      takeaway:
        "Consistency across listings had a bigger impact than any single ranking tactic.",
    },
  },
  {
    slug: "bloomhaus-social-growth",
    client: "BloomHaus",
    industry: "Lifestyle & Retail",
    service: "Social Media Growth",
    category: "Social",
    projectType: "Organic + paid social system",
    summary: "Grew an engaged audience and turned content into a sales channel.",
    result: "4.6x growth in attributable social revenue",
    gradient: "from-[#ff8fab] via-[#c15a74] to-[#271018]",
    metrics: [
      { label: "Followers", value: "+212%" },
      { label: "Engagement", value: "+3.4x" },
      { label: "Social revenue", value: "4.6x" },
    ],
    caseStudy: {
      challenge:
        "BloomHaus had beautiful products but social content wasn't translating into measurable sales.",
      approach:
        "We rebuilt the content system around shoppable formats and paired organic growth with targeted retargeting.",
      execution: [
        "Rebuilt content calendar around shoppable formats",
        "Introduced UGC and creator partnerships",
        "Layered retargeting campaigns behind top content",
        "Added attribution tracking for social revenue",
      ],
      results: ["+212% follower growth", "3.4x engagement rate", "4.6x attributable social revenue"],
      takeaway:
        "Social growth became a real revenue channel once content and retargeting worked together.",
    },
  },
  {
    slug: "futurelab-demand-generation",
    client: "FutureLab",
    industry: "SaaS",
    service: "Demand Generation",
    category: "Lead Generation",
    projectType: "B2B pipeline generation",
    summary: "Built a predictable demo-request pipeline for a B2B SaaS product.",
    result: "+88% sales-qualified demo requests",
    gradient: "from-[#8fe36b] via-[#3f8f6c] to-[#0d1f18]",
    metrics: [
      { label: "SQLs", value: "+88%" },
      { label: "CAC", value: "-19%" },
      { label: "Trial-to-paid", value: "+12pp" },
    ],
    caseStudy: {
      challenge:
        "FutureLab's trial sign-ups were growing, but very few converted into real sales conversations.",
      approach:
        "We rebuilt the demand-generation funnel to prioritize qualified demo requests over raw sign-up volume.",
      execution: [
        "Rebuilt landing pages around buyer-stage messaging",
        "Launched LinkedIn + Google Search campaigns",
        "Introduced lead scoring tied to product usage",
        "Aligned sales handoff with marketing qualification",
      ],
      results: ["+88% sales-qualified demo requests", "-19% customer acquisition cost", "+12pp trial-to-paid conversion"],
      takeaway:
        "Qualifying demand earlier in the funnel improved every metric sales cared about.",
    },
  },
  {
    slug: "vertex-finance-trust-rebuild",
    client: "Vertex Finance",
    industry: "Professional Services",
    service: "Brand Strategy + SEO",
    category: "Brand Growth",
    projectType: "Positioning & organic authority",
    summary: "Repositioned a financial advisory brand and rebuilt organic authority.",
    result: "+64% organic consultation requests",
    gradient: "from-[#c9c9d8] via-[#6d6d84] to-[#15151c]",
    metrics: [
      { label: "Organic traffic", value: "+97%" },
      { label: "Consult requests", value: "+64%" },
      { label: "Domain authority", value: "+18pts" },
    ],
    caseStudy: {
      challenge:
        "Vertex Finance looked generic online and struggled to earn trust against larger competitors.",
      approach:
        "We repositioned the brand around specialist expertise and rebuilt content to earn organic authority.",
      execution: [
        "Repositioned brand messaging around specialization",
        "Rebuilt site content and technical SEO foundation",
        "Published authority-building long-form content",
        "Earned relevant backlinks through outreach",
      ],
      results: ["+97% organic traffic", "+64% consultation requests", "+18 point domain authority increase"],
      takeaway:
        "Sharper positioning made every piece of content work harder for organic authority.",
    },
  },
  {
    slug: "nexora-commerce-cro",
    client: "Nexora Commerce",
    industry: "E-commerce — Fashion",
    service: "Conversion Rate Optimization",
    category: "E-commerce",
    projectType: "Landing-page & checkout optimization",
    summary: "Systematic testing program across product and checkout pages.",
    result: "+41% landing-page conversion rate",
    gradient: "from-[#ff9f5a] via-[#e35b3a] to-[#2a140f]",
    metrics: [
      { label: "CVR", value: "+41%" },
      { label: "Cart abandon", value: "-18%" },
      { label: "Revenue / visitor", value: "+33%" },
    ],
    caseStudy: {
      challenge:
        "Strong traffic volume wasn't translating into proportional revenue growth for Nexora Commerce.",
      approach:
        "We ran a structured testing program across product pages, cart, and checkout to remove friction.",
      execution: [
        "Audited funnel with heatmaps and session recordings",
        "Ran 14 structured A/B tests over one quarter",
        "Simplified checkout from 4 steps to 2",
        "Rebuilt product page trust and urgency signals",
      ],
      results: ["+41% landing-page conversion", "-18% cart abandonment", "+33% revenue per visitor"],
      takeaway:
        "A disciplined testing cadence outperformed one-off redesign guesses.",
    },
  },
];
