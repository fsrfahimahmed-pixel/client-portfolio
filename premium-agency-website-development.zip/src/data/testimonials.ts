export interface Testimonial {
  quote: string;
  name: string;
  role: string;
  company: string;
  industry: string;
}

export const testimonialsData: Testimonial[] = [
  {
    quote:
      "Nexora rebuilt our paid social from scratch. Within a quarter the creative testing cadence alone changed how we think about marketing.",
    name: "Sadia Rahman",
    role: "Marketing Director",
    company: "LumaSkin",
    industry: "Beauty & E-commerce",
  },
  {
    quote:
      "We stopped chasing lead volume and started chasing lead quality. Our sales team actually looks forward to the weekly report now.",
    name: "Kamal Hossain",
    role: "Head of Sales",
    company: "UrbanKey",
    industry: "Real Estate",
  },
  {
    quote:
      "Reporting used to be a black box. Now every dollar of spend maps to a business outcome we can defend in the boardroom.",
    name: "Farzana Akter",
    role: "CEO",
    company: "Vertex Finance",
    industry: "Professional Services",
  },
  {
    quote:
      "The team treats our brand like their own. That's rare in agency work, and it shows up in the quality of the creative.",
    name: "Omar Siddique",
    role: "Founder",
    company: "BloomHaus",
    industry: "Lifestyle & Retail",
  },
  {
    quote:
      "Our local SEO was invisible across half our clinics. Nexora fixed it methodically, location by location, and bookings followed.",
    name: "Dr. Nusrat Jahan",
    role: "Operations Lead",
    company: "Cliniq Plus",
    industry: "Healthcare",
  },
  {
    quote:
      "They speak both languages — creative and analytics — which is exactly what a scaling SaaS company needs from a growth partner.",
    name: "Tahmid Islam",
    role: "VP Growth",
    company: "FutureLab",
    industry: "SaaS",
  },
];
