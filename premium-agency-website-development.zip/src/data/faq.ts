export interface FaqItem {
  question: string;
  answer: string;
}

export const faqData: FaqItem[] = [
  {
    question: "What services do you offer?",
    answer:
      "We cover the full digital marketing stack: digital strategy, performance marketing, Google Ads, Meta Ads, SEO, local SEO, content strategy, conversion rate optimization, email marketing, marketing automation, e-commerce growth, brand strategy, and analytics & reporting.",
  },
  {
    question: "How do you start a project?",
    answer:
      "Every engagement starts with a strategy sprint — we audit your current funnel, audience, and channels before recommending where to invest. You'll get a 90-day roadmap before any budget moves.",
  },
  {
    question: "Do you work with international clients?",
    answer:
      "Yes. While we're based in Dhaka, roughly half of our active clients are international brands across North America, the Middle East, and Southeast Asia.",
  },
  {
    question: "Do you manage Google and Meta campaigns directly?",
    answer:
      "Yes, both are run in-house by dedicated specialists. We don't outsource media buying, which keeps optimization fast and accountable.",
  },
  {
    question: "How do you measure results?",
    answer:
      "We measure against business outcomes — qualified leads, cost per acquisition, ROAS, and retention — not vanity metrics like impressions or reach alone.",
  },
  {
    question: "How long before we see results?",
    answer:
      "Paid channels typically show early signal within 2–4 weeks. SEO and content compound over 3–6 months. We set realistic expectations for each channel during onboarding.",
  },
  {
    question: "Can you work alongside our existing marketing team?",
    answer:
      "Absolutely. We often operate as an extension of an in-house team, handling specific channels while your team owns brand and product strategy.",
  },
  {
    question: "Do you offer monthly retainers?",
    answer:
      "Yes, our Growth and Scale packages are structured as monthly retainers with quarterly strategy reviews. Launch is positioned for shorter, focused engagements.",
  },
  {
    question: "Can you handle creative production in-house?",
    answer:
      "Yes. Our creative and motion design team produces ad creative, landing pages, and content assets as part of most engagements.",
  },
  {
    question: "How do we get started?",
    answer:
      "Submit a project brief through our contact form or talk to a specialist through the chat widget. We'll schedule a strategy call within two business days.",
  },
];
