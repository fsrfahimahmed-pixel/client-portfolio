export interface TeamMember {
  name: string;
  role: string;
  specialty: string;
  skills: string[];
  quote?: string;
  initials: string;
  gradient: string;
}

export const founderProfile: TeamMember = {
  name: "Arian Rahman",
  role: "Founder & Strategy Lead",
  specialty: "Growth strategy & performance marketing",
  skills: ["Strategy", "Paid Media", "Analytics"],
  quote:
    "We don't sell activity. We sell outcomes — and we build the systems to prove it.",
  initials: "AR",
  gradient: "from-[#c8ff3d] to-[#5fae2b]",
};

export const teamData: TeamMember[] = [
  founderProfile,
  {
    name: "Nadia Karim",
    role: "Performance Marketing Specialist",
    specialty: "Google Ads & Performance Max",
    skills: ["Google Ads", "PMax", "Tracking"],
    initials: "NK",
    gradient: "from-[#7c6cff] to-[#4b3fae]",
  },
  {
    name: "Rafi Hasan",
    role: "Creative Strategist",
    specialty: "Paid social creative testing",
    skills: ["Meta Ads", "Creative Testing", "Hooks"],
    initials: "RH",
    gradient: "from-[#4fd8e0] to-[#1f8c92]",
  },
  {
    name: "Maya Chowdhury",
    role: "SEO Specialist",
    specialty: "Technical & local SEO",
    skills: ["Technical SEO", "Local SEO", "Content"],
    initials: "MC",
    gradient: "from-[#ffd166] to-[#c98a2c]",
  },
  {
    name: "Tanvir Ahmed",
    role: "Content & Social Lead",
    specialty: "Editorial strategy & organic social",
    skills: ["Content", "Social", "Copy"],
    initials: "TA",
    gradient: "from-[#ff8fab] to-[#b84f6c]",
  },
  {
    name: "Farhana Islam",
    role: "Motion & Visual Designer",
    specialty: "Creative production & design systems",
    skills: ["Motion", "Design Systems", "Branding"],
    initials: "FI",
    gradient: "from-[#8fe36b] to-[#3f8f6c]",
  },
  {
    name: "Imran Chowdhury",
    role: "Account & Client Success Manager",
    specialty: "Client partnerships & delivery",
    skills: ["Client Success", "Reporting", "Ops"],
    initials: "IC",
    gradient: "from-[#c9c9d8] to-[#6d6d84]",
  },
];
