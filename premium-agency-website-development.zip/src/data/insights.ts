export interface InsightArticle {
  slug: string;
  category: string;
  title: string;
  excerpt: string;
  readTime: string;
  date: string;
  content: string[];
}

export const insightsData: InsightArticle[] = [
  {
    slug: "creative-testing-beats-guessing",
    category: "Creative",
    title: "Why creative testing beats guessing",
    excerpt:
      "The brands winning on paid social aren't more talented — they just test more often, more systematically.",
    readTime: "6 min read",
    date: "2025-11-04",
    content: [
      "Most paid social accounts run two or three ad variations and call it 'creative testing.' Real testing requires volume, structure, and a willingness to kill ideas that don't perform.",
      "We run a minimum of six new creative concepts per week for active accounts, each testing a single variable — hook, format, or offer — so results are actually attributable.",
      "The compounding effect is the real unlock: after twelve weeks, the account has a library of proven hooks and formats that dramatically lower the cost of every new campaign.",
    ],
  },
  {
    slug: "landing-page-mistakes-killing-paid-traffic",
    category: "Conversion",
    title: "7 landing page mistakes killing paid traffic",
    excerpt:
      "Spending more on ads won't fix a landing page that doesn't match the promise of the click.",
    readTime: "5 min read",
    date: "2025-10-18",
    content: [
      "Mismatched messaging between ad and landing page is the single biggest conversion killer we see in audits.",
      "Other common issues: slow load times, unclear primary action, too many competing offers, and forms that ask for more than the visitor is ready to give.",
      "Fixing these seven issues typically lifts conversion rate before a single dollar of additional ad spend is needed.",
    ],
  },
  {
    slug: "how-to-structure-a-growth-funnel",
    category: "Strategy",
    title: "How to structure a growth funnel",
    excerpt:
      "A funnel isn't a diagram — it's a decision framework for where every marketing dollar should go.",
    readTime: "7 min read",
    date: "2025-09-29",
    content: [
      "Attention, engagement, intent, conversion, retention — each stage needs a distinct goal, channel mix, and success metric.",
      "The most common strategic mistake is optimizing top-of-funnel metrics while bottom-of-funnel conversion quietly degrades.",
      "We build funnel maps before any campaign goes live so every channel has a clear job description.",
    ],
  },
  {
    slug: "organic-vs-paid-where-to-invest",
    category: "Strategy",
    title: "Organic vs paid: where should a growing brand invest?",
    excerpt:
      "The honest answer is both — but the sequencing and ratio depend entirely on your growth stage.",
    readTime: "6 min read",
    date: "2025-09-08",
    content: [
      "Early-stage brands often need paid media to generate the data that makes organic strategy effective.",
      "As the brand matures, organic channels should take on a larger share of acquisition because the marginal cost approaches zero.",
      "We typically recommend a 70/30 paid-to-organic ratio in year one, shifting toward 40/60 by year three for most mid-market brands.",
    ],
  },
  {
    slug: "ad-reporting-business-outcomes",
    category: "Analytics",
    title: "Why ad reporting should focus on business outcomes",
    excerpt:
      "Impressions and reach tell you almost nothing about whether marketing is actually working.",
    readTime: "4 min read",
    date: "2025-08-21",
    content: [
      "A dashboard full of vanity metrics creates a false sense of progress while revenue impact stays unclear.",
      "We anchor every report in three questions: what did this cost, what did it generate, and is that ratio improving.",
      "Switching to outcome-based reporting often reveals which channels should actually get more budget.",
    ],
  },
];
