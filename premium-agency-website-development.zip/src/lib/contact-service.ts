/**
 * Project inquiry submission service.
 *
 * This is a clean abstraction boundary between the UI layer and the
 * eventual backend. In this phase it simulates a network call and stores
 * a demo copy of the payload locally so the UI can show realistic states.
 *
 * Future: replace the body of this function with a real API call, e.g.
 *   await fetch("/api/inquiries", { method: "POST", body: JSON.stringify(payload) })
 * The backend will then: validate -> create lead -> create project ->
 * determine department -> notify founder -> notify manager.
 */

export interface ProjectInquiryPayload {
  name: string;
  email: string;
  company: string;
  phone: string;
  service: string;
  budget: string;
  projectType: string;
  message: string;
  submittedAt: string;
  source: string;
}

export interface SubmissionResult {
  success: boolean;
  referenceId: string;
}

function generateReferenceId() {
  return `NXG-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
}

export async function submitProjectInquiry(
  payload: Omit<ProjectInquiryPayload, "submittedAt" | "source">,
): Promise<SubmissionResult> {
  const fullPayload: ProjectInquiryPayload = {
    ...payload,
    submittedAt: new Date().toISOString(),
    source: "public-website",
  };

  // Simulate network latency for a believable demo submission flow.
  await new Promise((resolve) => setTimeout(resolve, 900));

  if (typeof window !== "undefined") {
    try {
      const existing = JSON.parse(
        window.localStorage.getItem("nexora_demo_inquiries") ?? "[]",
      );
      existing.push(fullPayload);
      window.localStorage.setItem(
        "nexora_demo_inquiries",
        JSON.stringify(existing),
      );
    } catch {
      // Non-critical in demo mode.
    }
  }

  return { success: true, referenceId: generateReferenceId() };
}
