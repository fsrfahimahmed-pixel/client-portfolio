/**
 * Lightweight analytics abstraction.
 *
 * Future: wire this up to a real analytics provider (GA4, PostHog, etc.)
 * without touching any call sites across the app.
 */
type EventPayload = Record<string, string | number | boolean | undefined>;

export function trackEvent(eventName: string, payload: EventPayload = {}) {
  if (process.env.NODE_ENV !== "production") {
    // eslint-disable-next-line no-console
    console.debug(`[analytics] ${eventName}`, payload);
  }
  // Future: send to analytics provider via a server proxy route.
}
