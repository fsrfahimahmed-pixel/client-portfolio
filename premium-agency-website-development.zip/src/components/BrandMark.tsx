import { cn } from "@/lib/utils";

interface BrandMarkProps {
  size?: number;
  className?: string;
  withWordmark?: boolean;
}

/** Original geometric logo mark: an ascending cut square representing growth + precision. */
export default function BrandMark({ size = 32, className, withWordmark = false }: BrandMarkProps) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 40 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        <rect width="40" height="40" rx="11" fill="#c6ff52" />
        <path d="M11 27V13L22 27V13" stroke="#0d1403" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M27 20L27 13" stroke="#0d1403" strokeWidth="3.2" strokeLinecap="round" />
        <circle cx="27" cy="25.5" r="1.9" fill="#0d1403" />
      </svg>
      {withWordmark ? (
        <span className="text-lg font-semibold tracking-tight text-ink">
          Nexora <span className="text-ink-muted font-normal">Growth</span>
        </span>
      ) : null}
    </div>
  );
}
