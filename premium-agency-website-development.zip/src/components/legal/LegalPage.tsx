import type { ReactNode } from "react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

export default function LegalPage({
  title,
  updated,
  children,
}: {
  title: string;
  updated: string;
  children: ReactNode;
}) {
  return (
    <>
      <Navbar />
      <main className="container-nexora min-h-[60vh] pt-36 pb-28">
        <span className="label-micro text-accent">Legal</span>
        <h1 className="mt-3 text-4xl font-semibold tracking-tight text-ink">{title}</h1>
        <p className="mt-2 text-sm text-ink-faint">{updated}</p>
        <div className="mt-10 max-w-2xl space-y-5 text-sm leading-relaxed text-ink-muted">
          {children}
        </div>
      </main>
      <Footer />
    </>
  );
}
