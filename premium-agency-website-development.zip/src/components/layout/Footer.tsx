import Link from "next/link";
import { ArrowUpRight, Globe, AtSign, Hash, Share2 } from "lucide-react";
import { siteConfig } from "@/config/site";
import BrandMark from "@/components/BrandMark";
import { buttonClasses } from "@/components/ui/buttonStyles";
import Reveal from "@/components/ui/Reveal";

const footerColumns = [
  {
    title: "Services",
    links: [
      { label: "Performance Marketing", href: "/#services" },
      { label: "Google Ads", href: "/#services" },
      { label: "Meta Ads", href: "/#services" },
      { label: "SEO", href: "/#services" },
      { label: "Conversion Optimization", href: "/#services" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", href: "/#about" },
      { label: "Process", href: "/#process" },
      { label: "Selected Work", href: "/#work" },
      { label: "Team", href: "/#team" },
      { label: "Careers (demo)", href: "/#contact" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Insights", href: "/#insights" },
      { label: "Pricing", href: "/#pricing" },
      { label: "FAQ", href: "/#faq" },
      { label: "Contact", href: "/#contact" },
    ],
  },
  {
    title: "Workspace",
    links: [
      { label: "Client & Team Portal", href: "/login" },
      { label: "Privacy Policy", href: "/legal/privacy" },
      { label: "Terms of Service", href: "/legal/terms" },
      { label: "Cookie Policy", href: "/legal/cookies" },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-line bg-bg-soft pt-24">
      <div
        className="pointer-events-none absolute left-1/2 top-0 h-[480px] w-[900px] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-20 blur-[120px]"
        style={{ background: "radial-gradient(circle, var(--color-accent), transparent 70%)" }}
        aria-hidden="true"
      />
      <div className="container-nexora relative">
        <Reveal direction="up">
          <div className="flex flex-col gap-6 border-b border-line pb-16 sm:flex-row sm:items-end sm:justify-between">
            <h2 className="max-w-xl text-balance text-[clamp(1.9rem,4vw,3rem)] font-semibold leading-tight tracking-tight text-ink">
              Let&apos;s build something worth talking about.
            </h2>
            <div className="flex flex-wrap gap-3">
              <Link href="/#contact" className={buttonClasses("primary", "lg")}>
                {siteConfig.cta.primary}
                <ArrowUpRight className="h-4 w-4" />
              </Link>
              <Link href="/#contact" className={buttonClasses("secondary", "lg")}>
                {siteConfig.cta.talkToExpert}
              </Link>
            </div>
          </div>
        </Reveal>

        <div className="grid grid-cols-2 gap-10 py-16 sm:grid-cols-3 lg:grid-cols-6">
          <div className="col-span-2 flex flex-col gap-4 lg:col-span-2">
            <BrandMark size={32} withWordmark />
            <p className="max-w-xs text-sm leading-relaxed text-ink-muted">{siteConfig.tagline}</p>
            <div className="flex items-center gap-3 pt-2">
              {[
                { icon: Share2, href: siteConfig.social.linkedin, label: "LinkedIn" },
                { icon: AtSign, href: siteConfig.social.instagram, label: "Instagram" },
                { icon: Hash, href: siteConfig.social.x, label: "X" },
                { icon: Globe, href: siteConfig.social.facebook, label: "Facebook" },
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-line text-ink-muted transition hover:border-accent/50 hover:text-accent"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {footerColumns.map((col) => (
            <div key={col.title} className="flex flex-col gap-3">
              <p className="label-micro text-ink-faint">{col.title}</p>
              {col.links.map((link) => (
                <Link
                  key={link.label}
                  href={link.href}
                  className="text-sm text-ink-muted transition hover:text-accent"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          ))}
        </div>

        <div className="flex flex-col gap-3 border-t border-line py-8 text-xs text-ink-faint sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {new Date().getFullYear()} {siteConfig.name}. {siteConfig.location}. Demo content for
            prototype purposes.
          </p>
          <div className="flex gap-4">
            <Link href="/legal/privacy" className="hover:text-ink-muted">
              Privacy
            </Link>
            <Link href="/legal/terms" className="hover:text-ink-muted">
              Terms
            </Link>
            <Link href="/legal/cookies" className="hover:text-ink-muted">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
