"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { MoreHorizontal, ArrowUpRight, X } from "lucide-react";
import { siteConfig } from "@/config/site";
import BrandMark from "@/components/BrandMark";
import { buttonClasses } from "@/components/ui/buttonStyles";
import { cn } from "@/lib/utils";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [utilityOpen, setUtilityOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-[160] transition-all duration-500",
        scrolled ? "py-3" : "py-5",
      )}
    >
      <div className="container-nexora">
        <div
          className={cn(
            "flex items-center justify-between rounded-full border border-transparent px-4 py-2.5 transition-all duration-500",
            scrolled && "glass border-line px-5 shadow-[0_10px_40px_rgba(0,0,0,0.35)]",
          )}
        >
          <Link href="/#home" className="shrink-0" data-cursor="view">
            <BrandMark size={32} withWordmark />
          </Link>

          <nav className="hidden items-center gap-7 lg:flex">
            {siteConfig.nav.primary.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="group relative text-sm font-medium text-ink-muted transition-colors hover:text-ink"
              >
                {item.label}
                <span className="absolute -bottom-1 left-0 h-px w-0 bg-accent transition-all duration-300 group-hover:w-full" />
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <div className="hidden sm:block">
              <Link href="/#contact" className={buttonClasses("primary", "sm")} data-cursor="view">
                {siteConfig.cta.primary}
                <ArrowUpRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            <div className="relative">
              <button
                type="button"
                onClick={() => setUtilityOpen((v) => !v)}
                aria-label="Open utility menu"
                aria-expanded={utilityOpen}
                className="flex h-10 w-10 items-center justify-center rounded-full border border-line bg-white/[0.03] text-ink transition hover:border-accent/50 hover:text-accent"
              >
                <MoreHorizontal className="h-4.5 w-4.5" />
              </button>
              <AnimatePresence>
                {utilityOpen ? (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setUtilityOpen(false)} />
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9, y: -8 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: -8 }}
                      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                      className="glass-strong absolute right-0 top-12 z-50 w-56 overflow-hidden rounded-2xl p-2 shadow-[0_20px_60px_rgba(0,0,0,0.45)]"
                    >
                      {siteConfig.nav.utility.map((item, i) => (
                        <motion.div
                          key={item.href}
                          initial={{ opacity: 0, x: 8 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.04 }}
                        >
                          <Link
                            href={item.href}
                            onClick={() => setUtilityOpen(false)}
                            className={cn(
                              "flex items-center justify-between rounded-xl px-3 py-2.5 text-sm text-ink-muted transition hover:bg-white/[0.06] hover:text-ink",
                              item.href === "/login" && "font-semibold text-accent",
                            )}
                          >
                            {item.label}
                            <ArrowUpRight className="h-3.5 w-3.5 opacity-50" />
                          </Link>
                        </motion.div>
                      ))}
                    </motion.div>
                  </>
                ) : null}
              </AnimatePresence>
            </div>

            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation menu"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-line bg-white/[0.03] text-ink lg:hidden"
            >
              <span className="flex flex-col gap-[3px]">
                <span className="h-[1.5px] w-4 bg-current" />
                <span className="h-[1.5px] w-4 bg-current" />
              </span>
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {mobileOpen ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[170] flex flex-col bg-bg/98 backdrop-blur-xl lg:hidden"
          >
            <div className="container-nexora flex items-center justify-between py-5">
              <BrandMark size={30} withWordmark />
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                aria-label="Close menu"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-line text-ink"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="container-nexora flex flex-1 flex-col justify-center gap-2 pb-20">
              {[...siteConfig.nav.primary, ...siteConfig.nav.utility].map((item, i) => (
                <motion.div
                  key={item.href}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.08 + i * 0.05, ease: [0.16, 1, 0.3, 1] }}
                >
                  <Link
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className="flex items-center justify-between border-b border-line py-4 text-3xl font-semibold tracking-tight text-ink"
                  >
                    {item.label}
                    <ArrowUpRight className="h-5 w-5 text-ink-faint" />
                  </Link>
                </motion.div>
              ))}
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="mt-8"
              >
                <Link
                  href="/#contact"
                  onClick={() => setMobileOpen(false)}
                  className={buttonClasses("primary", "lg", "w-full")}
                >
                  {siteConfig.cta.primary}
                </Link>
              </motion.div>
            </nav>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </header>
  );
}
