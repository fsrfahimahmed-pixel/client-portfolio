"use client";

import { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

interface ModalProps {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
  variant?: "modal" | "drawer-right" | "sheet-bottom";
  className?: string;
  labelledBy?: string;
}

/**
 * Shared modal / drawer foundation used by service details, case studies,
 * and the chat panel. Handles ESC, click-outside, scroll lock, and
 * adapts to a bottom sheet on small viewports when variant="sheet-bottom".
 */
export default function Modal({ open, onClose, children, variant = "modal", className, labelledBy }: ModalProps) {
  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKey);
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handleKey);
      document.body.style.overflow = original;
    };
  }, [open, onClose]);

  const panelPosition =
    variant === "drawer-right"
      ? "ml-auto h-full max-w-xl"
      : variant === "sheet-bottom"
        ? "mt-auto w-full max-h-[88vh] rounded-b-none"
        : "m-auto max-h-[88vh] w-full max-w-3xl";

  const initial =
    variant === "drawer-right"
      ? { x: 60, opacity: 0 }
      : variant === "sheet-bottom"
        ? { y: 60, opacity: 0 }
        : { y: 24, opacity: 0, scale: 0.98 };
  const animate = variant === "drawer-right" ? { x: 0, opacity: 1 } : { y: 0, opacity: 1, scale: 1 };
  const exit =
    variant === "drawer-right"
      ? { x: 60, opacity: 0 }
      : variant === "sheet-bottom"
        ? { y: 60, opacity: 0 }
        : { y: 24, opacity: 0, scale: 0.98 };

  return (
    <AnimatePresence>
      {open ? (
        <motion.div
          className="fixed inset-0 z-[150] flex p-0 sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby={labelledBy}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
        >
          <motion.div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={onClose}
            aria-hidden="true"
          />
          <motion.div
            initial={initial}
            animate={animate}
            exit={exit}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className={cn(
              "glass-strong relative z-10 flex w-full flex-col overflow-hidden rounded-card shadow-[0_30px_100px_rgba(0,0,0,0.55)]",
              panelPosition,
              className,
            )}
          >
            <button
              type="button"
              onClick={onClose}
              aria-label="Close dialog"
              className="absolute right-4 top-4 z-20 flex h-9 w-9 items-center justify-center rounded-full border border-line bg-black/40 text-ink transition hover:border-accent/60 hover:text-accent"
            >
              <X className="h-4 w-4" />
            </button>
            <div className="overflow-y-auto">{children}</div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
