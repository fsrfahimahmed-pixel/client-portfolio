import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

export function Pill({ className, children, ...props }: HTMLAttributes<HTMLSpanElement>) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-line bg-white/[0.04] px-3 py-1 text-xs font-medium text-ink-muted",
        className,
      )}
      {...props}
    >
      {children}
    </span>
  );
}

export function Badge({ className, children, ...props }: HTMLAttributes<HTMLSpanElement>) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full bg-accent/15 px-3 py-1 text-xs font-semibold text-accent",
        className,
      )}
      {...props}
    >
      {children}
    </span>
  );
}
