import { cn } from "@/lib/utils";

export type ButtonVariant = "primary" | "secondary" | "ghost" | "text" | "icon";
export type ButtonSize = "sm" | "md" | "lg";

export const buttonBase =
  "relative inline-flex items-center justify-center gap-2 whitespace-nowrap font-semibold transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] focus-visible:outline-none disabled:opacity-50 disabled:pointer-events-none";

export const buttonVariants: Record<ButtonVariant, string> = {
  primary:
    "bg-accent text-accent-ink rounded-full shadow-[0_0_0_1px_rgba(198,255,82,0.4),0_8px_30px_rgba(198,255,82,0.18)] hover:shadow-[0_0_0_1px_rgba(198,255,82,0.6),0_10px_40px_rgba(198,255,82,0.32)] hover:-translate-y-0.5 active:translate-y-0",
  secondary:
    "glass text-ink rounded-full hover:border-line-strong hover:bg-white/[0.08] hover:-translate-y-0.5 active:translate-y-0",
  ghost:
    "bg-transparent text-ink border border-line rounded-full hover:border-accent/50 hover:text-accent",
  text: "bg-transparent text-ink underline-offset-4 hover:underline px-0",
  icon: "bg-white/[0.04] border border-line rounded-full hover:border-accent/50 hover:text-accent",
};

export const buttonSizes: Record<ButtonSize, string> = {
  sm: "text-xs px-4 py-2",
  md: "text-sm px-6 py-3",
  lg: "text-base px-8 py-4",
};

/** Shared so non-button elements (e.g. Next's Link) can reuse button styling from server components. */
export function buttonClasses(
  variant: ButtonVariant = "primary",
  size: ButtonSize = "md",
  className?: string,
) {
  const isIconOnly = variant === "icon";
  return cn(
    buttonBase,
    buttonVariants[variant],
    isIconOnly ? "h-10 w-10 p-0" : buttonSizes[size],
    className,
  );
}
