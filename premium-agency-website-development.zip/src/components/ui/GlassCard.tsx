import type { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

interface GlassCardProps extends HTMLAttributes<HTMLDivElement> {
  level?: 1 | 2 | 3;
}

/**
 * Three-tier glass surface system:
 * 1 = near-transparent, 2 = soft glass, 3 = elevated / strong glass.
 */
export default function GlassCard({ level = 2, className, children, ...props }: GlassCardProps) {
  return (
    <div
      className={cn(
        "rounded-card",
        level === 1 && "bg-white/[0.02] border border-line",
        level === 2 && "glass",
        level === 3 && "glass-strong shadow-[0_20px_60px_rgba(0,0,0,0.35)]",
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}
