"use client";

import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring, AnimatePresence } from "framer-motion";

/**
 * Desktop-only custom cursor: small dot + trailing ring. Interactive
 * elements can set `data-cursor="view|explore|drag"` to change the label.
 * Automatically disabled on touch devices and when reduced motion is set.
 */
export default function CustomCursor() {
  const [enabled, setEnabled] = useState(false);
  const [label, setLabel] = useState<string | null>(null);
  const [visible, setVisible] = useState(false);

  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const ringX = useSpring(x, { stiffness: 320, damping: 28 });
  const ringY = useSpring(y, { stiffness: 320, damping: 28 });

  useEffect(() => {
    const isCoarse = window.matchMedia("(pointer: coarse)").matches;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (isCoarse || reduced) return;
    setEnabled(true);

    const move = (e: MouseEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
      setVisible(true);
      const target = e.target as HTMLElement;
      const cursorEl = target.closest("[data-cursor]") as HTMLElement | null;
      setLabel(cursorEl?.getAttribute("data-cursor") ?? null);
    };
    const leave = () => setVisible(false);

    window.addEventListener("mousemove", move);
    document.documentElement.addEventListener("mouseleave", leave);
    return () => {
      window.removeEventListener("mousemove", move);
      document.documentElement.removeEventListener("mouseleave", leave);
    };
  }, [x, y]);

  if (!enabled) return null;

  const labelText =
    label === "view"
      ? "View"
      : label === "explore"
        ? "Explore"
        : label === "drag"
          ? "Drag"
          : label === "open"
            ? "Open"
            : null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[300] hidden md:block" aria-hidden="true">
      <AnimatePresence>
        {visible ? (
          <motion.div
            className="fixed left-0 top-0 h-2 w-2 rounded-full bg-accent"
            style={{ x, y, translateX: "-50%", translateY: "-50%" }}
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.5 }}
            transition={{ duration: 0.15 }}
          />
        ) : null}
      </AnimatePresence>
      <AnimatePresence>
        {visible ? (
          <motion.div
            className="fixed left-0 top-0 flex items-center justify-center rounded-full border border-accent/50"
            style={{ x: ringX, y: ringY, translateX: "-50%", translateY: "-50%" }}
            initial={{ opacity: 0, width: 32, height: 32 }}
            animate={{
              opacity: 1,
              width: labelText ? 72 : 32,
              height: labelText ? 72 : 32,
              backgroundColor: labelText ? "rgba(198,255,82,0.1)" : "rgba(198,255,82,0)",
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          >
            {labelText ? (
              <span className="text-[10px] font-semibold uppercase tracking-[0.15em] text-accent">
                {labelText}
              </span>
            ) : null}
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}
