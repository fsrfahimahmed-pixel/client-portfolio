import { performanceMetrics } from "@/config/site";
import MetricCounter from "@/components/ui/MetricCounter";
import Reveal from "@/components/ui/Reveal";

export default function Metrics() {
  return (
    <section className="relative overflow-hidden border-y border-line bg-bg-soft py-20">
      <div
        className="pointer-events-none absolute left-1/2 top-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-10 blur-[160px]"
        style={{ background: "radial-gradient(circle, var(--color-violet), transparent 70%)" }}
        aria-hidden="true"
      />
      <div className="container-nexora relative">
        <Reveal direction="up">
          <p className="label-micro mb-10 text-center text-ink-faint">
            Campaign Intelligence · Selected benchmark data
          </p>
        </Reveal>
        <div className="grid grid-cols-2 gap-10 sm:grid-cols-3 lg:grid-cols-5">
          {performanceMetrics.map((metric, i) => (
            <Reveal key={metric.label} direction="up" delay={i * 0.08} className="text-center">
              <p className="text-3xl font-semibold text-ink sm:text-4xl">
                <MetricCounter value={metric.value} suffix={metric.suffix} />
              </p>
              <p className="mt-2 text-xs leading-snug text-ink-faint">{metric.label}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
