"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import { cn } from "@/lib/utils";
import { projectsData } from "@/data/projects";

const featured = projectsData[0];

const tabs = {
  Leads: { unit: "qualified leads / mo", values: [120, 148, 176, 201, 232, 260] },
  CPL: { unit: "cost per lead (USD)", values: [42, 38, 35, 33, 30, 29] },
  ROAS: { unit: "return on ad spend", values: [1.4, 1.8, 2.1, 2.4, 2.6, 2.8] },
  "Conversion Rate": { unit: "landing page CVR", values: [2.1, 2.6, 3.0, 3.4, 3.8, 4.1] },
} as const;

type TabKey = keyof typeof tabs;

export default function CaseStudy() {
  const [activeTab, setActiveTab] = useState<TabKey>("Leads");
  const data = tabs[activeTab];
  const max = Math.max(...data.values);

  return (
    <section className="relative py-28 sm:py-36">
      <div className="container-nexora">
        <SectionHeading
          eyebrow="Featured Case Study"
          title="From scattered ad spend to a predictable acquisition system."
          description={`${featured.client} — ${featured.industry}`}
        />

        <div className="mt-14 grid gap-10 lg:grid-cols-2">
          <div className="flex flex-col gap-6">
            {[
              { label: "Challenge", text: featured.caseStudy.challenge },
              { label: "Strategy", text: featured.caseStudy.approach },
            ].map((block) => (
              <div key={block.label} className="rounded-card border border-line bg-white/[0.02] p-6">
                <p className="label-micro mb-2 text-accent">{block.label}</p>
                <p className="text-sm leading-relaxed text-ink-muted">{block.text}</p>
              </div>
            ))}
            <div className="rounded-card border border-line bg-white/[0.02] p-6">
              <p className="label-micro mb-3 text-accent">Execution</p>
              <ul className="space-y-2 text-sm text-ink-muted">
                {featured.caseStudy.execution.map((item) => (
                  <li key={item} className="flex gap-2">
                    <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-accent" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <Link
              href={`/work/${featured.slug}`}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-accent"
            >
              Read the full case study <ArrowUpRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="rounded-card border border-line bg-white/[0.02] p-6 sm:p-8">
            <div className="flex flex-wrap gap-2">
              {(Object.keys(tabs) as TabKey[]).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setActiveTab(tab)}
                  className={cn(
                    "rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all duration-300",
                    activeTab === tab
                      ? "border-accent bg-accent text-accent-ink"
                      : "border-line text-ink-muted hover:text-ink",
                  )}
                >
                  {tab}
                </button>
              ))}
            </div>

            <p className="mt-5 text-xs text-ink-faint">{data.unit} · 6-month trend (demo data)</p>

            <div className="mt-6 flex h-52 items-end gap-3 sm:gap-4">
              <AnimatePresence mode="wait">
                {data.values.map((value, i) => (
                  <motion.div
                    key={`${activeTab}-${i}`}
                    className="flex flex-1 flex-col items-center gap-2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <motion.div
                      className="w-full rounded-t-md bg-gradient-to-t from-accent/40 to-accent"
                      initial={{ height: 0 }}
                      whileInView={{ height: `${(value / max) * 100}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.8, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
                    />
                    <span className="text-[10px] text-ink-faint">M{i + 1}</span>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-4 border-t border-line pt-6 sm:grid-cols-4">
              {featured.caseStudy.results.map((result) => (
                <div key={result}>
                  <p className="text-lg font-semibold text-ink">{result.split(" ")[0]}</p>
                  <p className="text-[11px] leading-snug text-ink-faint">
                    {result.split(" ").slice(1).join(" ")}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
