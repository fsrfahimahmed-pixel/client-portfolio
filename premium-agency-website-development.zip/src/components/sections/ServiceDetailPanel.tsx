"use client";

import Link from "next/link";
import { ArrowUpRight, CheckCircle2 } from "lucide-react";
import Modal from "@/components/ui/Modal";
import { buttonClasses } from "@/components/ui/buttonStyles";
import type { ServiceItem } from "@/data/services";

interface ServiceDetailPanelProps {
  service: ServiceItem | null;
  onClose: () => void;
}

export default function ServiceDetailPanel({ service, onClose }: ServiceDetailPanelProps) {
  const isMobile = typeof window !== "undefined" && window.innerWidth < 640;

  return (
    <Modal
      open={!!service}
      onClose={onClose}
      variant={isMobile ? "sheet-bottom" : "drawer-right"}
      labelledBy="service-panel-title"
    >
      {service ? (
        <div className="flex h-full flex-col px-7 py-10 sm:px-9">
          <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-xl bg-accent/15 text-accent">
            <service.icon className="h-6 w-6" />
          </div>
          <h3 id="service-panel-title" className="text-3xl font-semibold tracking-tight text-ink">
            {service.name}
          </h3>
          <p className="mt-3 text-lg text-ink-muted">{service.shortDescription}</p>

          <div className="mt-8 space-y-6">
            <div>
              <p className="label-micro mb-2 text-ink-faint">Why it matters</p>
              <p className="text-sm leading-relaxed text-ink-muted">{service.whyItMatters}</p>
            </div>

            <div>
              <p className="label-micro mb-3 text-ink-faint">Deliverables</p>
              <ul className="grid gap-2.5 sm:grid-cols-2">
                {service.deliverables.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-sm text-ink">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border border-line bg-white/[0.03] p-5">
              <p className="label-micro mb-2 text-ink-faint">Typical outcome</p>
              <p className="text-sm leading-relaxed text-ink">{service.outcome}</p>
            </div>
          </div>

          <div className="mt-auto flex flex-wrap gap-3 pt-10">
            <Link
              href="/#contact"
              onClick={onClose}
              className={buttonClasses("primary", "lg")}
            >
              Discuss This Service
              <ArrowUpRight className="h-4 w-4" />
            </Link>
            <Link href="/#pricing" onClick={onClose} className={buttonClasses("ghost", "lg")}>
              View Pricing
            </Link>
          </div>
        </div>
      ) : null}
    </Modal>
  );
}
