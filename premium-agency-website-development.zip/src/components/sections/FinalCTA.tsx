import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { siteConfig } from "@/config/site";
import { buttonClasses } from "@/components/ui/buttonStyles";
import Reveal from "@/components/ui/Reveal";

export default function FinalCTA() {
  return (
    <section className="relative overflow-hidden py-28 sm:py-32">
      <div
        className="pointer-events-none absolute left-1/2 top-1/2 h-[500px] w-[900px] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-25 blur-[140px]"
        style={{ background: "radial-gradient(circle, var(--color-accent), transparent 70%)" }}
        aria-hidden="true"
      />
      <div className="container-nexora relative flex flex-col items-center gap-8 text-center">
        <Reveal direction="up">
          <span className="label-micro text-accent">Ready when you are</span>
        </Reveal>
        <Reveal direction="up" delay={0.08}>
          <h2 className="text-balance text-[clamp(2.25rem,6vw,4.5rem)] font-semibold leading-[1.05] tracking-tight text-ink">
            Your next growth story
            <br /> starts here.
          </h2>
        </Reveal>
        <Reveal direction="up" delay={0.16}>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/#contact" className={buttonClasses("primary", "lg")}>
              {siteConfig.cta.primary}
              <ArrowUpRight className="h-4 w-4" />
            </Link>
            <Link href="/#contact" className={buttonClasses("secondary", "lg")}>
              {siteConfig.cta.talkToExpert}
            </Link>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
