"use client";

import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { servicesData, type ServiceItem } from "@/data/services";
import SectionHeading from "@/components/ui/SectionHeading";
import ServiceDetailPanel from "./ServiceDetailPanel";
import { cn } from "@/lib/utils";
import { trackEvent } from "@/lib/analytics";

export default function Services() {
  const [active, setActive] = useState<ServiceItem | null>(null);
  const [hovered, setHovered] = useState<string | null>(null);
  const fieldRef = useRef<HTMLDivElement>(null);

  function openService(service: ServiceItem) {
    setActive(service);
    trackEvent("service_view", { service: service.slug });
  }

  return (
    <section id="services" className="relative py-28 sm:py-36">
      <div className="container-nexora">
        <SectionHeading
          eyebrow="What We Do"
          title="A full growth stack, not a one-channel bet."
          description="Move your cursor across the field — or tap on mobile — to explore each capability. Every service below is run by in-house specialists."
        />

        <div
          ref={fieldRef}
          className="mt-16 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3"
          onMouseLeave={() => setHovered(null)}
        >
          {servicesData.map((service, index) => {
            const isHovered = hovered === service.slug;
            const isDimmed = hovered !== null && !isHovered;
            return (
              <motion.button
                key={service.slug}
                type="button"
                onMouseEnter={() => setHovered(service.slug)}
                onFocus={() => setHovered(service.slug)}
                onClick={() => openService(service)}
                data-cursor="explore"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5, delay: (index % 3) * 0.08, ease: [0.16, 1, 0.3, 1] }}
                whileHover={{ scale: 1.015, rotate: index % 2 === 0 ? 0.4 : -0.4 }}
                animate={{ opacity: isDimmed ? 0.45 : 1 }}
                className={cn(
                  "group relative flex flex-col items-start gap-4 rounded-card border border-line bg-white/[0.02] p-6 text-left transition-colors duration-300",
                  isHovered && "border-accent/40 bg-white/[0.05] shadow-[0_20px_60px_rgba(198,255,82,0.08)]",
                )}
              >
                <div
                  className={cn(
                    "flex h-11 w-11 items-center justify-center rounded-xl bg-white/[0.05] text-ink-muted transition-colors duration-300",
                    isHovered && "bg-accent/15 text-accent",
                  )}
                >
                  <service.icon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-ink">{service.name}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink-muted">
                    {service.shortDescription}
                  </p>
                </div>
                <span className="mt-auto flex items-center gap-1.5 text-xs font-semibold text-accent opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                  Explore <ArrowRight className="h-3.5 w-3.5" />
                </span>
              </motion.button>
            );
          })}
        </div>
      </div>

      <ServiceDetailPanel service={active} onClose={() => setActive(null)} />
    </section>
  );
}
