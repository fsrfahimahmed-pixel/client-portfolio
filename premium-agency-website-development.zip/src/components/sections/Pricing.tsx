"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { pricingData } from "@/data/pricing";
import SectionHeading from "@/components/ui/SectionHeading";
import { buttonClasses } from "@/components/ui/buttonStyles";
import { cn } from "@/lib/utils";

export default function Pricing() {
  return (
    <section id="pricing" className="relative py-28 sm:py-36">
      <div className="container-nexora">
        <SectionHeading
          eyebrow="Engagement"
          title="Growth packages built around where you are today."
          description="Every engagement starts with a strategy sprint. Choose a starting point — we'll refine scope together."
          align="center"
        />

        <div className="mt-16 grid gap-6 lg:grid-cols-3">
          {pricingData.map((tier, index) => (
            <motion.div
              key={tier.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={cn(
                "relative flex flex-col gap-6 rounded-card border p-8",
                tier.highlighted
                  ? "border-accent/50 bg-gradient-to-b from-accent/10 to-transparent shadow-[0_30px_80px_rgba(198,255,82,0.12)] lg:-translate-y-4"
                  : "border-line bg-white/[0.02]",
              )}
            >
              {tier.highlighted ? (
                <span className="absolute -top-3 left-8 rounded-full bg-accent px-3 py-1 text-[11px] font-semibold text-accent-ink">
                  Most selected
                </span>
              ) : null}
              <div>
                <h3 className="text-xl font-semibold text-ink">{tier.name}</h3>
                <p className="mt-2 text-sm text-ink-muted">{tier.description}</p>
              </div>
              <div>
                <p className="text-2xl font-semibold text-ink">{tier.price}</p>
                <p className="mt-1 text-xs text-ink-faint">{tier.priceNote}</p>
              </div>
              <ul className="flex flex-1 flex-col gap-3 border-t border-line pt-6">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2 text-sm text-ink-muted">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Link
                href="/#contact"
                className={buttonClasses(tier.highlighted ? "primary" : "secondary", "md", "w-full")}
              >
                {tier.cta}
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
