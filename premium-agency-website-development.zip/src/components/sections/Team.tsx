"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { teamData } from "@/data/team";
import SectionHeading from "@/components/ui/SectionHeading";
import { cn } from "@/lib/utils";

export default function Team() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  return (
    <section id="team" className="relative py-28 sm:py-36">
      <div className="container-nexora">
        <SectionHeading
          eyebrow="Meet the Team"
          title="A small, senior team that stays close to the work."
          description="No account-manager layers between you and the specialists running your campaigns."
        />

        <div className="mt-14 flex gap-5 overflow-x-auto pb-4 no-scrollbar sm:grid sm:grid-cols-3 sm:overflow-visible lg:grid-cols-4">
          {teamData.map((member, index) => (
            <motion.div
              key={member.name}
              onMouseEnter={() => setActiveIndex(index)}
              onMouseLeave={() => setActiveIndex(null)}
              onClick={() => setActiveIndex(activeIndex === index ? null : index)}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: (index % 4) * 0.08 }}
              className={cn(
                "group relative w-[220px] shrink-0 cursor-pointer overflow-hidden rounded-card border border-line bg-white/[0.02] p-6 transition-all duration-500 sm:w-auto",
                activeIndex === index && "border-accent/40 bg-white/[0.05]",
              )}
            >
              <div
                className={cn(
                  "pointer-events-none absolute -right-6 -top-6 h-28 w-28 rounded-full bg-gradient-to-br opacity-0 blur-2xl transition-opacity duration-500",
                  member.gradient,
                  activeIndex === index && "opacity-30",
                )}
              />
              <div
                className={cn(
                  "relative flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br text-base font-bold text-accent-ink transition-transform duration-500",
                  member.gradient,
                  activeIndex === index && "scale-105 -translate-y-1",
                )}
              >
                {member.initials}
              </div>
              <h3 className="relative mt-5 text-base font-semibold text-ink">{member.name}</h3>
              <p className="relative mt-1 text-xs text-ink-muted">{member.role}</p>
              <div className="relative mt-4 flex flex-wrap gap-1.5">
                {member.skills.map((skill) => (
                  <span
                    key={skill}
                    className="rounded-full border border-line px-2 py-0.5 text-[10px] text-ink-faint"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
