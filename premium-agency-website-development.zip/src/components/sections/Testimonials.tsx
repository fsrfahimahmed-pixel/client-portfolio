"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { testimonialsData } from "@/data/testimonials";
import SectionHeading from "@/components/ui/SectionHeading";
import { cn } from "@/lib/utils";

export default function Testimonials() {
  const [index, setIndex] = useState(0);
  const total = testimonialsData.length;

  function go(dir: 1 | -1) {
    setIndex((prev) => (prev + dir + total) % total);
  }

  const current = testimonialsData[index];

  return (
    <section className="relative py-28 sm:py-36">
      <div className="container-nexora">
        <SectionHeading eyebrow="Client Voices" title="What it's like to work with us." align="center" />

        <div
          className="relative mx-auto mt-14 max-w-3xl"
          onKeyDown={(e) => {
            if (e.key === "ArrowLeft") go(-1);
            if (e.key === "ArrowRight") go(1);
          }}
          tabIndex={0}
          role="region"
          aria-label="Client testimonials carousel"
        >
          <Quote className="mx-auto mb-6 h-8 w-8 text-accent/60" />
          <AnimatePresence mode="wait">
            <motion.div
              key={current.name}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              className="text-center"
            >
              <p className="text-balance text-xl font-medium leading-relaxed text-ink sm:text-2xl">
                “{current.quote}”
              </p>
              <p className="mt-6 text-sm font-semibold text-ink">{current.name}</p>
              <p className="text-xs text-ink-faint">
                {current.role} · {current.company} · {current.industry}
              </p>
            </motion.div>
          </AnimatePresence>

          <div className="mt-10 flex items-center justify-center gap-4">
            <button
              type="button"
              onClick={() => go(-1)}
              aria-label="Previous testimonial"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-ink-muted transition hover:border-accent/50 hover:text-accent"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <div className="flex items-center gap-2">
              {testimonialsData.map((t, i) => (
                <button
                  key={t.name}
                  type="button"
                  onClick={() => setIndex(i)}
                  aria-label={`Go to testimonial ${i + 1}`}
                  className={cn(
                    "h-1.5 rounded-full transition-all duration-300",
                    i === index ? "w-6 bg-accent" : "w-1.5 bg-line-strong",
                  )}
                />
              ))}
            </div>
            <button
              type="button"
              onClick={() => go(1)}
              aria-label="Next testimonial"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-ink-muted transition hover:border-accent/50 hover:text-accent"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
