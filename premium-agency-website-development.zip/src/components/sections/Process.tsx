"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { processData } from "@/data/process";
import SectionHeading from "@/components/ui/SectionHeading";
import { cn } from "@/lib/utils";

export default function Process() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeStep, setActiveStep] = useState(0);

  useEffect(() => {
    const items = containerRef.current?.querySelectorAll<HTMLDivElement>("[data-step]");
    if (!items || items.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const idx = Number(entry.target.getAttribute("data-step"));
            setActiveStep(idx);
          }
        });
      },
      { threshold: 0.6, rootMargin: "-20% 0px -20% 0px" },
    );
    items.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, []);

  return (
    <section id="process" className="relative py-28 sm:py-36">
      <div className="container-nexora">
        <SectionHeading
          eyebrow="How We Work"
          title="A disciplined process built for measurable outcomes."
          description="Six stages carry every engagement from first audit to scaled growth."
        />

        <div className="mt-16 grid gap-12 lg:grid-cols-[auto_1fr]">
          <div className="hidden flex-col items-center lg:flex">
            <div className="relative h-[520px] w-px bg-line">
              <motion.div
                className="absolute left-0 top-0 w-px bg-accent"
                animate={{ height: `${((activeStep + 1) / processData.length) * 100}%` }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              />
            </div>
          </div>

          <div ref={containerRef} className="flex flex-col gap-10">
            {processData.map((step, index) => (
              <div
                key={step.number}
                data-step={index}
                className={cn(
                  "flex gap-6 rounded-card border border-transparent p-5 transition-all duration-500",
                  activeStep === index && "border-line bg-white/[0.03]",
                )}
              >
                <div
                  className={cn(
                    "flex h-12 w-12 shrink-0 items-center justify-center rounded-full border text-sm font-semibold transition-all duration-500",
                    activeStep === index
                      ? "border-accent bg-accent text-accent-ink scale-105"
                      : activeStep > index
                        ? "border-accent/40 text-accent"
                        : "border-line text-ink-faint",
                  )}
                >
                  {step.number}
                </div>
                <div>
                  <h3
                    className={cn(
                      "text-xl font-semibold transition-colors duration-500 sm:text-2xl",
                      activeStep === index ? "text-ink" : "text-ink-muted",
                    )}
                  >
                    {step.title}
                  </h3>
                  <p className="mt-2 max-w-xl text-sm leading-relaxed text-ink-muted">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
