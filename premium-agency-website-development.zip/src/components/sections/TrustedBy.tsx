import { trustedByBrands } from "@/config/site";
import Reveal from "@/components/ui/Reveal";

export default function TrustedBy() {
  const loop = [...trustedByBrands, ...trustedByBrands];
  return (
    <section className="border-y border-line bg-bg-soft/60 py-10">
      <div className="container-nexora">
        <Reveal direction="up" duration={0.5}>
          <p className="label-micro mb-6 text-center text-ink-faint">
            Selected brand partnerships (demo roster)
          </p>
        </Reveal>
        <div className="no-scrollbar overflow-hidden">
          <div className="animate-marquee flex w-max items-center gap-16">
            {loop.map((brand, i) => (
              <span
                key={`${brand}-${i}`}
                className="text-xl font-semibold tracking-tight text-ink-faint/70 sm:text-2xl"
              >
                {brand}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
