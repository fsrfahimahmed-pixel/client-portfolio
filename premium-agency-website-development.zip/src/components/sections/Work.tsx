"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence, LayoutGroup } from "framer-motion";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { projectsData, type Project } from "@/data/projects";
import SectionHeading from "@/components/ui/SectionHeading";
import { cn } from "@/lib/utils";
import { trackEvent } from "@/lib/analytics";

const filters = ["All", "Performance", "SEO", "Social", "E-commerce", "Lead Generation", "Brand Growth"] as const;

export default function Work() {
  const [filter, setFilter] = useState<(typeof filters)[number]>("All");

  const visibleProjects = useMemo(
    () => (filter === "All" ? projectsData : projectsData.filter((p) => p.category === filter)),
    [filter],
  );

  return (
    <section id="work" className="relative py-28 sm:py-36">
      <div className="container-nexora">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            eyebrow="Selected Work"
            title="Campaigns built to prove the strategy, not just the creative."
            description="A sample of engagements across industries. Every number shown is demo case-study data."
            className="max-w-xl"
          />
          <div className="flex flex-wrap gap-2">
            {filters.map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setFilter(f)}
                className={cn(
                  "rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all duration-300",
                  filter === f
                    ? "border-accent bg-accent text-accent-ink"
                    : "border-line text-ink-muted hover:border-line-strong hover:text-ink",
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        <LayoutGroup>
          <motion.div layout className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            <AnimatePresence mode="popLayout">
              {visibleProjects.map((project) => (
                <ProjectCard key={project.slug} project={project} />
              ))}
            </AnimatePresence>
          </motion.div>
        </LayoutGroup>
      </div>
    </section>
  );
}

function ProjectCard({ project }: { project: Project }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
    >
      <Link
        href={`/work/${project.slug}`}
        onClick={() => trackEvent("project_view", { projectId: project.slug })}
        data-cursor="view"
        className="group relative flex h-full flex-col overflow-hidden rounded-card border border-line bg-white/[0.02] transition-all duration-500 hover:-translate-y-1 hover:border-line-strong"
      >
        <div className={cn("relative h-44 overflow-hidden bg-gradient-to-br", project.gradient)}>
          <div className="absolute inset-0 bg-black/20 transition-opacity duration-500 group-hover:opacity-0" />
          <div className="absolute inset-0 flex items-end p-5">
            <span className="rounded-full bg-black/40 px-3 py-1 text-[11px] font-medium text-white backdrop-blur-sm">
              {project.category}
            </span>
          </div>
          <ArrowUpRight className="absolute right-4 top-4 h-5 w-5 text-white/80 transition-transform duration-500 group-hover:translate-x-1 group-hover:-translate-y-1" />
        </div>
        <div className="flex flex-1 flex-col gap-3 p-6">
          <div>
            <p className="label-micro text-ink-faint">{project.industry}</p>
            <h3 className="mt-1.5 text-lg font-semibold text-ink">{project.client}</h3>
          </div>
          <p className="text-sm leading-relaxed text-ink-muted">{project.summary}</p>
          <div className="mt-auto flex flex-wrap gap-4 border-t border-line pt-4">
            {project.metrics.slice(0, 2).map((metric) => (
              <div key={metric.label}>
                <p className="text-base font-semibold text-accent">{metric.value}</p>
                <p className="text-[11px] text-ink-faint">{metric.label}</p>
              </div>
            ))}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
