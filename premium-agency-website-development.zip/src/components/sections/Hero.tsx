"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowUpRight, ArrowDown, TrendingUp, Sparkles } from "lucide-react";
import { siteConfig, heroMetrics } from "@/config/site";
import { buttonClasses } from "@/components/ui/buttonStyles";
import MagneticButton from "@/components/ui/MagneticButton";
import MetricCounter from "@/components/ui/MetricCounter";
import GlassCard from "@/components/ui/GlassCard";

const headlineLines = ["Marketing that", "moves the", "business."];

const container = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.12, delayChildren: 0.2 } },
};
const lineVariant = {
  hidden: { y: "110%", opacity: 0 },
  visible: { y: "0%", opacity: 1, transition: { duration: 0.9, ease: [0.16, 1, 0.3, 1] as const } },
};

export default function Hero() {
  return (
    <section id="home" className="relative flex min-h-[100svh] items-center overflow-hidden pt-28 pb-16">
      <div
        className="pointer-events-none absolute -top-40 right-[-10%] h-[520px] w-[520px] rounded-full opacity-30 blur-[140px]"
        style={{ background: "radial-gradient(circle, var(--color-accent), transparent 70%)" }}
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute bottom-[-20%] left-[-10%] h-[420px] w-[420px] rounded-full opacity-20 blur-[140px]"
        style={{ background: "radial-gradient(circle, var(--color-violet), transparent 70%)" }}
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "linear-gradient(to right, var(--color-line-strong) 1px, transparent 1px), linear-gradient(to bottom, var(--color-line-strong) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
        }}
        aria-hidden="true"
      />

      <div className="container-nexora relative grid gap-14 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
        <div>
          <motion.span
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="label-micro mb-6 inline-flex items-center gap-2 rounded-full border border-line bg-white/[0.03] px-4 py-2 text-accent"
          >
            <Sparkles className="h-3.5 w-3.5" />
            Digital Marketing Agency · Dhaka &amp; Beyond
          </motion.span>

          <motion.h1
            variants={container}
            initial="hidden"
            animate="visible"
            className="text-[clamp(2.75rem,7.5vw,5.5rem)] font-semibold leading-[0.98] tracking-tight text-ink"
          >
            {headlineLines.map((line) => (
              <span key={line} className="block overflow-hidden">
                <motion.span className="block" variants={lineVariant}>
                  {line}
                </motion.span>
              </span>
            ))}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.75, ease: [0.16, 1, 0.3, 1] }}
            className="mt-7 max-w-lg text-balance text-lg leading-relaxed text-ink-muted"
          >
            {siteConfig.tagline} We blend strategy, creative, and performance data into growth
            systems for ambitious brands.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.9, ease: [0.16, 1, 0.3, 1] }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <MagneticButton>
              <Link href="/#contact" className={buttonClasses("primary", "lg")} data-cursor="view">
                {siteConfig.cta.primary}
                <ArrowUpRight className="h-4 w-4" />
              </Link>
            </MagneticButton>
            <Link href="/#work" className={buttonClasses("secondary", "lg")} data-cursor="explore">
              {siteConfig.cta.secondary}
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.3, duration: 0.6 }}
            className="mt-16 grid grid-cols-2 gap-6 border-t border-line pt-8 sm:grid-cols-4"
          >
            {heroMetrics.map((metric) => (
              <div key={metric.label}>
                <p className="text-2xl font-semibold text-ink sm:text-3xl">
                  <MetricCounter value={metric.value} suffix={metric.suffix} />
                </p>
                <p className="mt-1 text-xs leading-snug text-ink-faint">{metric.label}</p>
              </div>
            ))}
          </motion.div>
        </div>

        <div className="relative hidden h-[460px] lg:block">
          <FloatingMetricCards />
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6 }}
        className="absolute bottom-8 left-1/2 flex -translate-x-1/2 flex-col items-center gap-2 text-ink-faint"
      >
        <span className="label-micro">Scroll to explore</span>
        <motion.div animate={{ y: [0, 6, 0] }} transition={{ duration: 1.8, repeat: Infinity }}>
          <ArrowDown className="h-4 w-4" />
        </motion.div>
      </motion.div>
    </section>
  );
}

function FloatingMetricCards() {
  const cards = [
    { top: "4%", left: "6%", delay: 0, label: "ROAS", value: "3.7x", tone: "accent" },
    { top: "30%", left: "48%", delay: 0.6, label: "Qualified leads", value: "+68%", tone: "violet" },
    { top: "58%", left: "2%", delay: 1.1, label: "Creative test winner", value: "Hook B", tone: "highlight" },
    { top: "70%", left: "52%", delay: 1.6, label: "Cost per lead", value: "-29%", tone: "accent" },
  ] as const;

  return (
    <div className="relative h-full w-full">
      {cards.map((card) => (
        <motion.div
          key={card.label}
          className="animate-float-slow absolute w-[200px]"
          style={{ top: card.top, left: card.left, animationDelay: `${card.delay}s` }}
          initial={{ opacity: 0, scale: 0.8, y: 40 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 + card.delay, ease: [0.16, 1, 0.3, 1] }}
        >
          <GlassCard level={3} className="px-4 py-4">
            <div className="flex items-center justify-between">
              <span className="label-micro text-ink-faint">{card.label}</span>
              <TrendingUp
                className={
                  "h-3.5 w-3.5 " +
                  (card.tone === "accent"
                    ? "text-accent"
                    : card.tone === "violet"
                      ? "text-violet"
                      : "text-highlight")
                }
              />
            </div>
            <p className="mt-2 text-2xl font-semibold text-ink">{card.value}</p>
          </GlassCard>
        </motion.div>
      ))}
    </div>
  );
}
