"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Compass, Brush, Eye, Zap, Infinity as InfinityIcon, LineChart } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import { cn } from "@/lib/utils";

const principles = [
  {
    icon: Compass,
    title: "Strategy before execution",
    description: "No campaign launches without a documented hypothesis and success metric.",
    metric: "100% of campaigns start with a strategy brief",
  },
  {
    icon: Brush,
    title: "Creative with commercial intent",
    description: "Every creative asset is built to move a specific funnel metric, not just to look good.",
    metric: "6+ creative concepts tested weekly",
  },
  {
    icon: Eye,
    title: "Transparent reporting",
    description: "Live dashboards and plain-language summaries — no vanity metrics dressed up as wins.",
    metric: "Bi-weekly reporting cadence",
  },
  {
    icon: Zap,
    title: "Fast communication",
    description: "A dedicated strategist means questions get answered in hours, not weeks.",
    metric: "< 24h average response time",
  },
  {
    icon: InfinityIcon,
    title: "Full-funnel thinking",
    description: "Acquisition, conversion, and retention are planned together, not in silos.",
    metric: "Attention → retention mapped per client",
  },
  {
    icon: LineChart,
    title: "Continuous optimization",
    description: "Weekly testing cycles mean accounts get more efficient the longer we run them.",
    metric: "Weekly optimization cycles",
  },
];

export default function WhyUs() {
  const [active, setActive] = useState<number | null>(null);

  return (
    <section className="relative py-28 sm:py-36">
      <div className="container-nexora">
        <SectionHeading
          eyebrow="Why Choose Us"
          title="Built for brands that expect their marketing to be accountable."
          description="Six operating principles that shape every engagement, regardless of package size."
        />

        <div className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {principles.map((item, index) => {
            const isActive = active === index;
            return (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5, delay: (index % 3) * 0.08 }}
                onMouseEnter={() => setActive(index)}
                onMouseLeave={() => setActive(null)}
                onClick={() => setActive(isActive ? null : index)}
                className={cn(
                  "group relative cursor-pointer overflow-hidden rounded-card border border-line bg-white/[0.02] p-6 transition-colors duration-300",
                  isActive && "border-accent/40 bg-white/[0.05]",
                )}
              >
                <item.icon
                  className={cn(
                    "h-6 w-6 text-ink-muted transition-all duration-500",
                    isActive && "text-accent rotate-6 scale-110",
                  )}
                />
                <h3 className="mt-4 text-base font-semibold text-ink">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-muted">{item.description}</p>
                <motion.div
                  initial={false}
                  animate={{ height: isActive ? "auto" : 0, opacity: isActive ? 1 : 0 }}
                  transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                  className="overflow-hidden"
                >
                  <p className="mt-4 border-t border-line pt-3 text-xs font-medium text-accent">
                    {item.metric}
                  </p>
                </motion.div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
