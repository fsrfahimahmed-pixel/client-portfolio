import { ExternalLink } from "lucide-react";
import Reveal from "@/components/ui/Reveal";
import GlassCard from "@/components/ui/GlassCard";
import { founderProfile } from "@/data/team";
import { siteConfig } from "@/config/site";

const stats = [
  { label: "Founded", value: `${siteConfig.foundedYear}` },
  { label: "Specialists", value: "7" },
  { label: "Avg. engagement length", value: "14 mo" },
];

export default function About() {
  return (
    <section id="about" className="relative py-28 sm:py-36">
      <div className="container-nexora grid gap-16 lg:grid-cols-2 lg:gap-12">
        <Reveal direction="left">
          <div className="flex flex-col gap-6">
            <span className="label-micro text-accent">About Nexora Growth</span>
            <h2 className="text-balance text-[clamp(2rem,4vw,3.25rem)] font-semibold leading-[1.1] tracking-tight text-ink">
              We combine creative instinct with performance discipline.
            </h2>
            <p className="max-w-md text-balance text-base leading-relaxed text-ink-muted sm:text-lg">
              Nexora Growth was built on a simple premise: creative work and performance data
              should never live in separate teams. Every strategy we run is informed by both
              sides from day one — which is why our campaigns tend to get more efficient the
              longer we run them, not less.
            </p>
            <div className="mt-4 grid grid-cols-3 gap-6 border-t border-line pt-6">
              {stats.map((stat) => (
                <div key={stat.label}>
                  <p className="text-2xl font-semibold text-ink">{stat.value}</p>
                  <p className="mt-1 text-xs text-ink-faint">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        <Reveal direction="right" delay={0.1}>
          <GlassCard level={3} className="relative overflow-hidden p-8">
            <div
              className="pointer-events-none absolute -right-10 -top-10 h-56 w-56 rounded-full opacity-30 blur-3xl"
              style={{ background: "radial-gradient(circle, var(--color-accent), transparent 70%)" }}
              aria-hidden="true"
            />
            <div className="relative flex items-center gap-4">
              <div
                className={`flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${founderProfile.gradient} text-lg font-bold text-accent-ink`}
              >
                {founderProfile.initials}
              </div>
              <div>
                <p className="text-lg font-semibold text-ink">{founderProfile.name}</p>
                <p className="text-sm text-ink-muted">{founderProfile.role}</p>
              </div>
            </div>
            <blockquote className="relative mt-6 text-balance text-xl font-medium leading-snug text-ink">
              “{founderProfile.quote}”
            </blockquote>
            <div className="relative mt-6 flex items-center justify-between border-t border-line pt-5">
              <span className="text-xs text-ink-faint">{founderProfile.specialty}</span>
              <a
                href={siteConfig.social.linkedin}
                target="_blank"
                rel="noreferrer"
                aria-label="Founder LinkedIn"
                className="flex h-8 w-8 items-center justify-center rounded-full border border-line text-ink-muted transition hover:border-accent/50 hover:text-accent"
              >
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </GlassCard>
        </Reveal>
      </div>
    </section>
  );
}
