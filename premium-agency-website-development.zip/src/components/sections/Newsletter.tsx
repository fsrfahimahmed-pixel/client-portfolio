"use client";

import { useState } from "react";
import { ArrowRight, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import Reveal from "@/components/ui/Reveal";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setStatus("error");
      return;
    }
    setStatus("success");
  }

  return (
    <section className="py-16">
      <div className="container-nexora">
        <Reveal direction="up">
          <div className="flex flex-col items-center gap-6 rounded-card border border-line bg-white/[0.02] px-6 py-14 text-center sm:px-16">
            <h3 className="text-balance text-2xl font-semibold tracking-tight text-ink sm:text-3xl">
              Useful growth ideas. No noise.
            </h3>
            <p className="max-w-md text-sm text-ink-muted">
              One short email a month with the tactics actually moving the needle for our clients.
            </p>
            {status === "success" ? (
              <div className="flex items-center gap-2 text-sm font-medium text-accent">
                <Check className="h-4 w-4" /> Demo subscription successful.
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex w-full max-w-md flex-col gap-3 sm:flex-row">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setStatus("idle");
                  }}
                  placeholder="you@company.com"
                  className={cn(
                    "w-full flex-1 rounded-full border bg-white/[0.04] px-5 py-3 text-sm text-ink placeholder:text-ink-faint focus:border-accent/60",
                    status === "error" ? "border-red-400/60" : "border-line",
                  )}
                />
                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-1.5 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-accent-ink transition hover:brightness-110"
                >
                  Subscribe <ArrowRight className="h-4 w-4" />
                </button>
              </form>
            )}
            {status === "error" ? (
              <span className="text-xs text-red-400">Please enter a valid email address.</span>
            ) : null}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
