"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, ArrowRight, CheckCircle2, Loader2 } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import { cn } from "@/lib/utils";
import { submitProjectInquiry } from "@/lib/contact-service";
import { useToast } from "@/components/ui/Toast";
import { servicesData } from "@/data/services";
import { siteConfig } from "@/config/site";

interface FormState {
  name: string;
  email: string;
  company: string;
  phone: string;
  service: string;
  budget: string;
  message: string;
}

const emptyForm: FormState = {
  name: "",
  email: "",
  company: "",
  phone: "",
  service: "",
  budget: "",
  message: "",
};

const budgets = ["< $1,000 / mo", "$1,000 – $3,000 / mo", "$3,000 – $8,000 / mo", "$8,000+ / mo", "Project-based"];

const steps = ["Your Details", "Project Scope", "Project Brief", "Confirmation"];

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export default function Contact() {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");
  const [referenceId, setReferenceId] = useState("");
  const { showToast } = useToast();

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  }

  function validateStep(current: number) {
    const nextErrors: Partial<Record<keyof FormState, string>> = {};
    if (current === 0) {
      if (!form.name.trim()) nextErrors.name = "Please tell us your name.";
      if (!isValidEmail(form.email)) nextErrors.email = "Please enter a valid work email.";
    }
    if (current === 1) {
      if (!form.service) nextErrors.service = "Select the service you're interested in.";
      if (!form.budget) nextErrors.budget = "Select an approximate budget range.";
    }
    if (current === 2) {
      if (form.message.trim().length < 12) {
        nextErrors.message = "Add a few more details so we can prepare for the call.";
      }
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  }

  function goNext() {
    if (!validateStep(step)) return;
    if (step === 2) {
      void handleSubmit();
      return;
    }
    setStep((s) => Math.min(s + 1, steps.length - 1));
  }

  function goBack() {
    setStep((s) => Math.max(s - 1, 0));
  }

  async function handleSubmit() {
    setStatus("submitting");
    try {
      const result = await submitProjectInquiry({
        name: form.name,
        email: form.email,
        company: form.company,
        phone: form.phone,
        service: form.service,
        budget: form.budget,
        projectType: form.service,
        message: form.message,
      });
      setReferenceId(result.referenceId);
      setStatus("success");
      setStep(3);
      showToast("Message prepared successfully.");
    } catch {
      setStatus("idle");
      showToast("Something went wrong. Please try again.");
    }
  }

  function resetForm() {
    setForm(emptyForm);
    setStep(0);
    setStatus("idle");
  }

  return (
    <section id="contact" className="relative py-28 sm:py-36">
      <div className="container-nexora grid gap-14 lg:grid-cols-[0.9fr_1.1fr]">
        <div>
          <SectionHeading
            eyebrow="Start a Project"
            title="Have something ambitious in mind?"
            description="Tell us about your business and goals. A specialist reviews every submission within two business days."
          />
          <div className="mt-10 space-y-4 border-t border-line pt-8 text-sm text-ink-muted">
            <p>
              Prefer a direct conversation? Use the chat widget in the corner to talk to our AI
              assistant or a human specialist.
            </p>
            <p>
              <span className="text-ink">Email:</span> {siteConfig.email}
            </p>
            <p>
              <span className="text-ink">Based in:</span> {siteConfig.location}
            </p>
          </div>
        </div>

        <div className="rounded-card border border-line bg-white/[0.02] p-6 sm:p-9">
          <div className="mb-8 flex items-center gap-2">
            {steps.map((label, i) => (
              <div key={label} className="flex flex-1 flex-col gap-2">
                <div className="h-1 overflow-hidden rounded-full bg-white/10">
                  <motion.div
                    className="h-full bg-accent"
                    initial={{ width: 0 }}
                    animate={{ width: i <= step ? "100%" : "0%" }}
                    transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                  />
                </div>
                <span className="hidden text-[10px] text-ink-faint sm:block">{label}</span>
              </div>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            >
              {step === 0 ? (
                <div className="grid gap-5">
                  <Field label="Full Name" error={errors.name}>
                    <input
                      value={form.name}
                      onChange={(e) => update("name", e.target.value)}
                      placeholder="Arian Rahman"
                      className={inputClass(!!errors.name)}
                    />
                  </Field>
                  <Field label="Work Email" error={errors.email}>
                    <input
                      value={form.email}
                      onChange={(e) => update("email", e.target.value)}
                      placeholder="you@company.com"
                      className={inputClass(!!errors.email)}
                    />
                  </Field>
                  <Field label="Company">
                    <input
                      value={form.company}
                      onChange={(e) => update("company", e.target.value)}
                      placeholder="Company name"
                      className={inputClass(false)}
                    />
                  </Field>
                  <Field label="Phone / WhatsApp">
                    <input
                      value={form.phone}
                      onChange={(e) => update("phone", e.target.value)}
                      placeholder="+880 1XXX-XXXXXX"
                      className={inputClass(false)}
                    />
                  </Field>
                </div>
              ) : null}

              {step === 1 ? (
                <div className="grid gap-5">
                  <Field label="Service Needed" error={errors.service}>
                    <select
                      value={form.service}
                      onChange={(e) => update("service", e.target.value)}
                      className={inputClass(!!errors.service)}
                    >
                      <option value="">Select a service</option>
                      {servicesData.map((s) => (
                        <option key={s.slug} value={s.name}>
                          {s.name}
                        </option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Budget Range" error={errors.budget}>
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                      {budgets.map((b) => (
                        <button
                          type="button"
                          key={b}
                          onClick={() => update("budget", b)}
                          className={cn(
                            "rounded-xl border px-3.5 py-2.5 text-left text-sm transition-all duration-300",
                            form.budget === b
                              ? "border-accent bg-accent/10 text-ink"
                              : "border-line text-ink-muted hover:border-line-strong",
                          )}
                        >
                          {b}
                        </button>
                      ))}
                    </div>
                  </Field>
                </div>
              ) : null}

              {step === 2 ? (
                <Field label="Project Brief" error={errors.message}>
                  <textarea
                    value={form.message}
                    onChange={(e) => update("message", e.target.value)}
                    rows={6}
                    placeholder="Tell us about your business, goals, and current marketing setup…"
                    className={inputClass(!!errors.message)}
                  />
                </Field>
              ) : null}

              {step === 3 ? (
                <div className="flex flex-col items-center gap-4 py-6 text-center">
                  <CheckCircle2 className="h-12 w-12 text-accent" />
                  <h3 className="text-xl font-semibold text-ink">Message sent.</h3>
                  <p className="max-w-xs text-sm text-ink-muted">
                    Reference <span className="text-ink">{referenceId}</span>. A specialist will
                    reach out to {form.email || "your email"} within two business days.
                  </p>
                  <button
                    type="button"
                    onClick={resetForm}
                    className="mt-2 text-sm font-semibold text-accent"
                  >
                    Submit another inquiry
                  </button>
                </div>
              ) : null}
            </motion.div>
          </AnimatePresence>

          {step < 3 ? (
            <div className="mt-8 flex items-center justify-between border-t border-line pt-6">
              <button
                type="button"
                onClick={goBack}
                disabled={step === 0}
                className="inline-flex items-center gap-1.5 text-sm text-ink-muted transition hover:text-ink disabled:opacity-30"
              >
                <ArrowLeft className="h-4 w-4" /> Back
              </button>
              <button
                type="button"
                onClick={goNext}
                disabled={status === "submitting"}
                className="inline-flex items-center gap-2 rounded-full bg-accent px-6 py-2.5 text-sm font-semibold text-accent-ink transition hover:brightness-110 disabled:opacity-60"
              >
                {status === "submitting" ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Submitting…
                  </>
                ) : step === 2 ? (
                  "Submit Brief"
                ) : (
                  <>
                    Continue <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </button>
            </div>
          ) : null}
        </div>
      </div>
    </section>
  );
}

function inputClass(hasError: boolean) {
  return cn(
    "w-full rounded-xl border bg-white/[0.03] px-4 py-3 text-sm text-ink placeholder:text-ink-faint transition-all duration-300 focus:bg-white/[0.06]",
    hasError ? "border-red-400/60 focus:border-red-400" : "border-line focus:border-accent/60",
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="flex flex-col gap-2">
      <span className="text-xs font-medium text-ink-muted">{label}</span>
      {children}
      {error ? <span className="text-xs text-red-400">{error}</span> : null}
    </label>
  );
}
