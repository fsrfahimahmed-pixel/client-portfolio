"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { industriesData } from "@/data/industries";
import SectionHeading from "@/components/ui/SectionHeading";
import { cn } from "@/lib/utils";

export default function Industries() {
  const [active, setActive] = useState(0);

  return (
    <section className="relative py-28 sm:py-36">
      <div className="container-nexora">
        <SectionHeading
          eyebrow="Who We Work With"
          title="Specialized playbooks for ten core industries."
          description="Select an industry to see how we approach it. Each vertical has its own benchmark data and channel priorities."
        />

        <div className="mt-14 grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="flex flex-wrap gap-2.5 lg:flex-col lg:gap-1">
            {industriesData.map((industry, index) => (
              <button
                key={industry.name}
                type="button"
                onClick={() => setActive(index)}
                className={cn(
                  "rounded-full px-4 py-2.5 text-left text-sm font-medium transition-all duration-300 lg:rounded-xl",
                  active === index
                    ? "bg-accent text-accent-ink lg:shadow-[0_10px_30px_rgba(198,255,82,0.18)]"
                    : "bg-white/[0.03] text-ink-muted hover:bg-white/[0.07] hover:text-ink",
                )}
              >
                {industry.name}
              </button>
            ))}
          </div>

          <div className="relative min-h-[220px] overflow-hidden rounded-card border border-line bg-white/[0.02] p-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={industriesData[active].name}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -16 }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              >
                <span className="label-micro text-accent">{industriesData[active].name}</span>
                <h3 className="mt-3 text-2xl font-semibold leading-snug text-ink sm:text-3xl">
                  {industriesData[active].description}
                </h3>
                <p className="mt-6 border-t border-line pt-5 text-sm text-ink-muted">
                  <span className="text-ink">Result example:</span> {industriesData[active].example}
                </p>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
