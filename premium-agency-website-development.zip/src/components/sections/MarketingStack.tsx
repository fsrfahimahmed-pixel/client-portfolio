import { marketingStack } from "@/config/site";
import Reveal from "@/components/ui/Reveal";

export default function MarketingStack() {
  return (
    <section className="py-16">
      <div className="container-nexora">
        <Reveal direction="up">
          <p className="label-micro mb-8 text-center text-ink-faint">Tools &amp; Platforms We Operate In</p>
        </Reveal>
        <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-4">
          {marketingStack.map((tool) => (
            <span key={tool} className="text-sm font-medium text-ink-faint transition hover:text-ink-muted">
              {tool}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
