"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Clock } from "lucide-react";
import { insightsData } from "@/data/insights";
import SectionHeading from "@/components/ui/SectionHeading";
import Modal from "@/components/ui/Modal";

export default function Insights() {
  const [activeSlug, setActiveSlug] = useState<string | null>(null);
  const activeArticle = insightsData.find((a) => a.slug === activeSlug) ?? null;

  return (
    <section id="insights" className="relative py-28 sm:py-36">
      <div className="container-nexora">
        <SectionHeading
          eyebrow="Insights"
          title="Growth ideas, documented honestly."
          description="Short, specific write-ups from the strategists running these campaigns day to day."
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {insightsData.map((article, index) => (
            <motion.button
              key={article.slug}
              type="button"
              onClick={() => setActiveSlug(article.slug)}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: (index % 3) * 0.08 }}
              data-cursor="view"
              className="group flex flex-col gap-4 rounded-card border border-line bg-white/[0.02] p-6 text-left transition-all duration-500 hover:-translate-y-1 hover:border-line-strong"
            >
              <div className="flex items-center justify-between">
                <span className="label-micro text-accent">{article.category}</span>
                <ArrowUpRight className="h-4 w-4 text-ink-faint transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1 group-hover:text-accent" />
              </div>
              <h3 className="text-lg font-semibold leading-snug text-ink">{article.title}</h3>
              <p className="text-sm leading-relaxed text-ink-muted">{article.excerpt}</p>
              <div className="mt-auto flex items-center gap-3 border-t border-line pt-4 text-xs text-ink-faint">
                <Clock className="h-3.5 w-3.5" />
                {article.readTime}
                <span>·</span>
                {new Date(article.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      <Modal open={!!activeArticle} onClose={() => setActiveSlug(null)} labelledBy="article-title">
        {activeArticle ? (
          <div className="px-7 py-10 sm:px-10">
            <span className="label-micro text-accent">{activeArticle.category}</span>
            <h3 id="article-title" className="mt-3 text-2xl font-semibold tracking-tight text-ink sm:text-3xl">
              {activeArticle.title}
            </h3>
            <div className="mt-2 flex items-center gap-3 text-xs text-ink-faint">
              <Clock className="h-3.5 w-3.5" />
              {activeArticle.readTime}
              <span>·</span>
              {new Date(activeArticle.date).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
            </div>
            <div className="mt-6 space-y-4">
              {activeArticle.content.map((paragraph, i) => (
                <p key={i} className="text-sm leading-relaxed text-ink-muted">
                  {paragraph}
                </p>
              ))}
            </div>
          </div>
        ) : null}
      </Modal>
    </section>
  );
}
