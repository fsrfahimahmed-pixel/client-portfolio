"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus } from "lucide-react";
import { faqData } from "@/data/faq";
import SectionHeading from "@/components/ui/SectionHeading";
import { cn } from "@/lib/utils";

export default function FAQ() {
  const [openIndexes, setOpenIndexes] = useState<number[]>([0]);

  function toggle(index: number) {
    setOpenIndexes((prev) => {
      if (prev.includes(index)) return prev.filter((i) => i !== index);
      if (prev.length >= 2) return [prev[prev.length - 1], index];
      return [...prev, index];
    });
  }

  return (
    <section id="faq" className="relative py-28 sm:py-36">
      <div className="container-nexora grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
        <SectionHeading
          eyebrow="FAQ"
          title="Answers before you ask."
          description="Can't find what you need? Ask our AI assistant or talk to a specialist via the chat widget."
        />

        <div className="flex flex-col divide-y divide-line border-t border-line">
          {faqData.map((item, index) => {
            const isOpen = openIndexes.includes(index);
            return (
              <div key={item.question} className="py-2">
                <button
                  type="button"
                  onClick={() => toggle(index)}
                  aria-expanded={isOpen}
                  className="flex w-full items-center justify-between gap-4 py-4 text-left"
                >
                  <span className="text-base font-medium text-ink sm:text-lg">{item.question}</span>
                  <motion.span
                    animate={{ rotate: isOpen ? 45 : 0 }}
                    transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                    className={cn(
                      "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-line text-ink-muted",
                      isOpen && "border-accent/50 text-accent",
                    )}
                  >
                    <Plus className="h-4 w-4" />
                  </motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen ? (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                      className="overflow-hidden"
                    >
                      <p className="pb-5 pr-10 text-sm leading-relaxed text-ink-muted">{item.answer}</p>
                    </motion.div>
                  ) : null}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
