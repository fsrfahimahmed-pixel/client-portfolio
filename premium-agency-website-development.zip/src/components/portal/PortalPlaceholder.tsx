import Link from "next/link";
import { Construction, ShieldCheck } from "lucide-react";
import GlassCard from "@/components/ui/GlassCard";
import { buttonClasses } from "@/components/ui/buttonStyles";

interface PortalPlaceholderProps {
  role: "Founder" | "Manager" | "Employee";
  description: string;
  capabilities: string[];
}

export default function PortalPlaceholder({ role, description, capabilities }: PortalPlaceholderProps) {
  return (
    <div className="container-nexora flex flex-1 items-center justify-center py-16">
      <GlassCard level={3} className="w-full max-w-2xl p-8 sm:p-12">
        <div className="flex items-center gap-2 text-xs font-medium text-accent">
          <ShieldCheck className="h-4 w-4" />
          Secure Operations Portal · Development Preview
        </div>
        <h1 className="mt-4 text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
          {role} Workspace
        </h1>
        <p className="mt-4 max-w-lg text-sm leading-relaxed text-ink-muted sm:text-base">
          {description}
        </p>

        <div className="mt-8 flex items-start gap-3 rounded-2xl border border-accent/30 bg-accent/5 p-5">
          <Construction className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
          <p className="text-sm leading-relaxed text-ink-muted">
            Portal integration is coming in the next build phase. This is a structural
            placeholder — no live data, authentication, or role permissions are connected yet.
          </p>
        </div>

        <div className="mt-8">
          <p className="label-micro mb-3 text-ink-faint">Planned capabilities</p>
          <ul className="grid gap-2 sm:grid-cols-2">
            {capabilities.map((item) => (
              <li
                key={item}
                className="flex items-center gap-2 rounded-xl border border-line bg-white/[0.02] px-3.5 py-2.5 text-xs text-ink-muted"
              >
                <span className="h-1.5 w-1.5 rounded-full bg-ink-faint" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-9 flex flex-wrap gap-3">
          <Link href="/login" className={buttonClasses("secondary", "md")}>
            Switch role preview
          </Link>
          <Link href="/" className={buttonClasses("ghost", "md")}>
            Return to website
          </Link>
        </div>
      </GlassCard>
    </div>
  );
}
