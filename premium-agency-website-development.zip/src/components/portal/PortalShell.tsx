import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import type { ReactNode } from "react";
import BrandMark from "@/components/BrandMark";

export default function PortalShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-bg">
      <div
        className="pointer-events-none absolute left-1/2 top-0 h-[600px] w-[900px] -translate-x-1/2 -translate-y-1/3 rounded-full opacity-20 blur-[140px]"
        style={{ background: "radial-gradient(circle, var(--color-violet), transparent 70%)" }}
        aria-hidden="true"
      />
      <header className="container-nexora relative flex items-center justify-between py-6">
        <Link href="/">
          <BrandMark size={30} withWordmark />
        </Link>
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-sm text-ink-muted transition hover:text-ink"
        >
          <ArrowLeft className="h-4 w-4" /> Back to website
        </Link>
      </header>
      <main className="relative flex flex-1 flex-col">{children}</main>
    </div>
  );
}
