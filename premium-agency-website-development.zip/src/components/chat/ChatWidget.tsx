"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { MessageCircle, X, Send, Phone, Mail, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { matchAiResponse, aiSuggestionChips } from "@/data/ai-knowledge";
import { siteConfig } from "@/config/site";
import { trackEvent } from "@/lib/analytics";

type Tab = "human" | "ai";

interface ChatMessage {
  id: number;
  from: "user" | "agent";
  text: string;
}

const humanStarters = [
  "I need a marketing strategy",
  "I want Google Ads",
  "I need more leads",
  "I want to discuss my project",
  "Show me your services",
];

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<Tab>("ai");
  const [aiMessages, setAiMessages] = useState<ChatMessage[]>([
    {
      id: 1,
      from: "agent",
      text: "Hi, I'm Nova — Nexora Growth's AI assistant. Ask me about services, results, or how to get started.",
    },
  ]);
  const [humanStarted, setHumanStarted] = useState(false);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [aiMessages, typing]);

  function sendAiMessage(text: string) {
    if (!text.trim()) return;
    const userMsg: ChatMessage = { id: Date.now(), from: "user", text };
    setAiMessages((prev) => [...prev, userMsg]);
    setInput("");
    setTyping(true);
    trackEvent("ai_agent_message_sent");
    setTimeout(() => {
      const reply = matchAiResponse(text);
      setAiMessages((prev) => [...prev, { id: Date.now() + 1, from: "agent", text: reply }]);
      setTyping(false);
    }, 850 + Math.random() * 500);
  }

  return (
    <>
      <div className="fixed bottom-5 right-4 z-[180] sm:bottom-7 sm:right-7">
        <AnimatePresence>
          {!open ? (
            <motion.button
              key="launcher"
              type="button"
              onClick={() => {
                setOpen(true);
                trackEvent("chat_widget_opened");
              }}
              initial={{ opacity: 0, scale: 0.7 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.7 }}
              whileHover={{ scale: 1.05 }}
              className="animate-pulse-ring group relative flex h-14 w-14 items-center justify-center rounded-full bg-accent text-accent-ink shadow-[0_10px_40px_rgba(198,255,82,0.35)]"
              aria-label="Open chat with Human or AI agent"
              data-cursor="open"
            >
              <MessageCircle className="h-6 w-6" />
              <span className="absolute -top-10 right-0 whitespace-nowrap rounded-full bg-surface-elevated px-3 py-1.5 text-xs font-medium text-ink opacity-0 shadow-lg transition-opacity duration-300 group-hover:opacity-100">
                Need help?
              </span>
            </motion.button>
          ) : null}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {open ? (
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.96 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="glass-strong fixed bottom-0 right-0 z-[190] flex h-[min(620px,100dvh)] w-full flex-col overflow-hidden rounded-t-card shadow-[0_30px_100px_rgba(0,0,0,0.55)] sm:bottom-6 sm:right-6 sm:h-[560px] sm:w-[380px] sm:rounded-card"
            role="dialog"
            aria-label="Support chat"
          >
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <div className="flex rounded-full bg-white/5 p-1 text-sm">
                <button
                  type="button"
                  onClick={() => setTab("ai")}
                  className={cn(
                    "rounded-full px-3 py-1.5 font-medium transition",
                    tab === "ai" ? "bg-accent text-accent-ink" : "text-ink-muted hover:text-ink",
                  )}
                >
                  AI Agent
                </button>
                <button
                  type="button"
                  onClick={() => setTab("human")}
                  className={cn(
                    "rounded-full px-3 py-1.5 font-medium transition",
                    tab === "human" ? "bg-accent text-accent-ink" : "text-ink-muted hover:text-ink",
                  )}
                >
                  Human Agent
                </button>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close chat"
                className="flex h-8 w-8 items-center justify-center rounded-full text-ink-muted transition hover:bg-white/10 hover:text-ink"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {tab === "ai" ? (
              <div className="flex flex-1 flex-col overflow-hidden">
                <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4 no-scrollbar">
                  {aiMessages.map((m) => (
                    <div
                      key={m.id}
                      className={cn("flex", m.from === "user" ? "justify-end" : "justify-start")}
                    >
                      <div
                        className={cn(
                          "max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed",
                          m.from === "user"
                            ? "bg-accent text-accent-ink"
                            : "border border-line bg-white/[0.04] text-ink",
                        )}
                      >
                        {m.text}
                      </div>
                    </div>
                  ))}
                  {typing ? (
                    <div className="flex items-center gap-1.5 rounded-2xl border border-line bg-white/[0.04] px-3.5 py-2.5 text-ink-muted w-fit">
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      <span className="text-xs">Nova is typing…</span>
                    </div>
                  ) : null}
                </div>
                <div className="flex flex-wrap gap-1.5 border-t border-line px-4 py-2.5">
                  {aiSuggestionChips.slice(0, 3).map((chip) => (
                    <button
                      key={chip}
                      type="button"
                      onClick={() => sendAiMessage(chip)}
                      className="rounded-full border border-line px-2.5 py-1 text-[11px] text-ink-muted transition hover:border-accent/50 hover:text-accent"
                    >
                      {chip}
                    </button>
                  ))}
                </div>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    sendAiMessage(input);
                  }}
                  className="flex items-center gap-2 border-t border-line p-3"
                >
                  <input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask Nova anything…"
                    aria-label="Message to AI assistant"
                    className="flex-1 rounded-full border border-line bg-white/[0.03] px-4 py-2.5 text-sm text-ink placeholder:text-ink-faint focus:border-accent/50"
                  />
                  <button
                    type="submit"
                    aria-label="Send message"
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent text-accent-ink transition hover:brightness-110"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </form>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto px-4 py-5">
                <div className="mb-4 flex items-center gap-2 text-xs text-ink-muted">
                  <span className="h-2 w-2 rounded-full bg-accent" />
                  Typical response: within business hours (demo)
                </div>
                <p className="mb-4 text-sm text-ink-muted">
                  Talk to a specialist about your project. Pick a starting point or reach us directly.
                </p>
                {!humanStarted ? (
                  <div className="flex flex-col gap-2">
                    {humanStarters.map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setHumanStarted(true)}
                        className="rounded-xl border border-line bg-white/[0.03] px-4 py-3 text-left text-sm text-ink transition hover:border-accent/40"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="rounded-xl border border-accent/30 bg-accent/10 px-4 py-3 text-sm text-ink">
                    Thanks! This is a demo channel — a specialist will follow up through the project
                    form or the contact details below.
                  </div>
                )}
                <div className="mt-6 grid gap-2.5">
                  <a
                    href={siteConfig.whatsapp}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-3 rounded-xl border border-line px-4 py-3 text-sm text-ink transition hover:border-accent/40"
                  >
                    <Phone className="h-4 w-4 text-accent" /> WhatsApp (demo number)
                  </a>
                  <a
                    href={`mailto:${siteConfig.email}`}
                    className="flex items-center gap-3 rounded-xl border border-line px-4 py-3 text-sm text-ink transition hover:border-accent/40"
                  >
                    <Mail className="h-4 w-4 text-accent" /> {siteConfig.email}
                  </a>
                  <a
                    href="#contact"
                    onClick={() => setOpen(false)}
                    className="flex items-center gap-3 rounded-xl border border-line px-4 py-3 text-sm text-ink transition hover:border-accent/40"
                  >
                    <Send className="h-4 w-4 text-accent" /> Send project details
                  </a>
                </div>
              </div>
            )}
          </motion.div>
        ) : null}
      </AnimatePresence>
    </>
  );
}
